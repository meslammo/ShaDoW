# SHADOW v0.37 Integration Notes

## Multi-Provider Brain
- Added `shadow.models` provider-neutral contracts.
- Added `OpenAIProvider` using the official OpenAI Responses API through the optional `openai` SDK dependency.
- API keys are not stored in source; the SDK uses `OPENAI_API_KEY` from the environment.
- Added `ModelRouter` with explicit default/preferred provider selection and fail-closed unknown-provider handling.
- Existing Planner/Critic contracts continue to consume provider-neutral `.complete(...)` responses.

## Verification
- Full test suite: 99 passed.
- Provider tests use an injected fake client; no network/API key required.


## v0.38
Integrated `ShadowBrain` with the reasoning stack. `ModelRouter` owns provider selection; Planner and Critic request task-specific routing without coupling to a concrete provider. Runtime supports composition from `brain + executor`.
