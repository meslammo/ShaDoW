# SHADOW v0.2

Core + adapter boundaries for:
- Voice pipeline
- Computer Use
- Browser
- MCP
- Memory
- EventBus

Heavy external implementations remain isolated behind adapters.

## v0.8 Live Solution Discovery

Shadow now has a real discovery/evaluation boundary before implementation decisions:

`Understand → Search Existing Solutions → Evaluate → REUSE / MODIFY / INTEGRATE / BUILD`

`ReasoningPolicyEngine` consumes `SolutionCandidate` records containing source, module, location, license, dependencies, quality, completeness, and compatibility. The engine fails closed on candidates without a known license and records every decision for later learning/audit.


### License Verification
Discovery results are now passed through `VerifiedSolutionDiscovery`/`LicenseVerifier`. GitHub repositories are verified through the GitHub license endpoint with a LICENSE-file fallback; generic web pages require recognizable license text. Unverified claims fail closed and cannot be selected for reuse.


## v0.11
- Added DependencyVerifier for Python dependency manifests and local version checks.
- GitHub repository dependency verification via pyproject.toml/requirements files.
- Fail-closed verification when no supported dependency manifest is found.

### Security Scanner (v0.13)
Shadow now has a lightweight pre-integration security gate for common high-risk Python patterns. It is intentionally conservative and is not a replacement for full SAST/sandboxing.


## v0.15 — Architecture Analyzer
- Added static ArchitectureAnalyzer for source-tree inspection without executing candidate code.
- Extracts modules, imports, symbols, entrypoints, dependency edges, and basic risk flags.
- Python uses AST parsing; other supported languages use conservative text extraction.
- Analyzer fails closed when the target is not a directory.


### Integration safety
Before integration, Shadow can detect changed-file conflicts and create a checkpoint for rollback preparation.


## v0.20
- Added DecisionScorer for explainable candidate ranking.
- Added CapabilityRegistry for capability discovery and missing-capability checks.
- Added AuditTrail for structured decision/execution history.
- Tests: 46 passed.

## v0.21 Learning
Shadow now records decision outcomes and can apply a small bounded confidence adjustment to future solution scoring. Safety, license, and compatibility gates remain authoritative.


## v0.23 Self-Healing
- Added bounded SelfHealingEngine for retry + conservative repair callbacks.
- Retries never bypass Shadow security, license, or compatibility gates.
- IntegrationTransaction can optionally invoke repair between failed regression attempts.
- Recovery remains bounded and fail-safe.
- Tests: 51 passed.

## v0.24 — Autonomous Agent Loop
The `shadow.agent` package now composes policy, planner, secure executor, critic,
verification, memory, bounded repair/retry, audit, and learning into one goal-driven loop.
The loop is bounded and never bypasses the executor's safety gate.

## v0.25 — Agent Hardening

- AutonomousAgentLoop now supports bounded adaptive replanning after critic/verification failure.
- SelfHealingEngine now has an async execution path for real async tools/providers.
- ShadowRuntime exposes `run_goal()` as the canonical goal-oriented entry point backed by AutonomousAgentLoop.
- Replanning and healing remain bounded and continue through the secure execution gateway.
- Test suite: 58 passed.

## v0.26 — Real Tool Boundaries
- Added constrained `FilesystemTool` with root traversal protection.
- Added `MCPTool` proxy so individual MCP tools pass through Shadow's normal executor boundary.
- Added `ToolCatalog` for explicit runtime registration and manifests.
- Existing Browser/Computer adapters remain provider-neutral and require injected runners.


## v0.27
Real MCP stdio JSON-RPC, Browser JSONL subprocess, and Computer-use JSONL subprocess boundaries. All remain behind SecureToolExecutor.

## v0.28 — Memory + Learning Integration
- MemoryStore now supports episodic, semantic, procedural, and failure memories.
- Recall uses deterministic token relevance with a small recency tie-breaker and supports typed filtering.
- AutonomousAgentLoop recalls relevant memory before planning and stores an episodic run record after completion/failure.
- Existing result memories remain available; external/vector backends can be injected through the same async boundary.

## v0.29 — Voice Runtime
- Provider-neutral Wake/VAD/STT/Brain/TTS pipeline.
- Async voice turns with context propagation.
- Streaming-compatible TTS boundary and cancellation/barge-in support.
- Callable adapters for integrating real providers without coupling the core.


## v0.30
- VisionAdapter + VisionPipeline (perceive → action → verify).
- ScreenAdapter for provider-neutral screen capture with isolated JSONL runner support.

## v0.31 — Android/Desktop Client Boundary

Added an authenticated local HTTP gateway plus a dependency-free desktop client and a stable mobile wire contract. Clients communicate with the Shadow core through `/v1/request`; tool execution remains inside the core and its security gateway.

## v0.32 — Device Control
- Explicit device catalog and capability inventory.
- Home Assistant REST transport using the Python standard library.
- Read-only state tool separated from write/control tool.
- Control services require an explicit service allowlist and remain risky, so SecureToolExecutor approval applies.
- No credentials are embedded in URLs; transport validates HTTP(S) endpoints and bounds requests.


## v0.33 — Security Hardening
- Fail-closed SecurityPolicy for tool permissions.
- SecretRedactor protects audit/log payloads.
- Environment-backed SecretStore boundary.
- SecureToolExecutor now enforces policy and records failures safely.
- Sandbox executable allowlist and secret-looking environment variable rejection.
- 85 tests passing.

## v0.34 — Evaluation & Reliability

Added a bounded reliability evaluation harness under `shadow/evaluation/`. It runs deterministic scenarios through the public Agent/Runtime entry point, enforces timeout and run-event invariants, and reports pass/fail metrics without bypassing security or execution gateways.


## v0.35 — Production Runtime
- Added `shadow.production` lifecycle/config/logging runtime boundary.
- Environment-driven configuration with bounded port/request/shutdown validation.
- Health snapshots, request/failure counters, component lifecycle, graceful gateway shutdown.
- Request timeout enforced around the canonical `ShadowRuntime.run_goal()` path.
- Logs pass through secret redaction.

## v0.36 — Executable Production Service
- `python -m shadow` is the production entrypoint.
- Configure `SHADOW_APP_FACTORY=module:factory` to provide the application composition.
- The factory must return `ProductionRuntime`; lifecycle and gateway startup remain centralized.
- SIGINT/SIGTERM trigger graceful shutdown.

## v0.37 — Multi-Provider Brain
- Provider-neutral model contract and response type.
- OpenAI Responses API adapter using the official `openai` SDK as an optional dependency.
- Explicit model router with fail-closed provider selection.
- No API keys stored in source; the SDK reads `OPENAI_API_KEY` from the environment.


## v0.38 — Brain Integration
- Added `ShadowBrain` as the model-facing boundary over `ModelRouter`.
- Planner and Critic now route through the Brain with explicit task labels (`planning`, `critique`).
- `ShadowRuntime` can build Planner/Critic directly from `brain + executor`.
- Provider selection remains fail-closed and tool execution remains independent from model output.
- The Brain never executes tools; it only supplies model responses to reasoning components.
- Test suite: 102 passed.
