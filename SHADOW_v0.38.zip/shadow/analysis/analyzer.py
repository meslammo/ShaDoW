from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import ast
import re
from typing import Iterable


@dataclass(frozen=True)
class ModuleInfo:
    path: str
    kind: str
    imports: tuple[str, ...] = ()
    symbols: tuple[str, ...] = ()
    risk_flags: tuple[str, ...] = ()


@dataclass
class ArchitectureReport:
    root: str
    modules: list[ModuleInfo] = field(default_factory=list)
    dependency_edges: list[tuple[str, str]] = field(default_factory=list)
    entrypoints: list[str] = field(default_factory=list)
    risky_modules: list[str] = field(default_factory=list)

    def module(self, path: str) -> ModuleInfo | None:
        return next((m for m in self.modules if m.path == path), None)


class ArchitectureAnalyzer:
    """Static, non-executing architecture inspection for candidate projects."""

    SOURCE_SUFFIXES = {".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".go", ".rs"}
    RISK_PATTERNS = {
        "shell": re.compile(r"\b(?:os\.system|subprocess\.|child_process|Runtime\.getRuntime|Command::new)\b"),
        "dynamic": re.compile(r"\b(?:eval|exec|__import__)\s*\("),
        "network": re.compile(r"\b(?:requests|httpx|urllib|fetch\s*\(|WebSocket|socket\.)"),
    }

    def analyze(self, root: str | Path) -> ArchitectureReport:
        base = Path(root).resolve()
        if not base.is_dir():
            raise NotADirectoryError(base)
        report = ArchitectureReport(str(base))
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in self.SOURCE_SUFFIXES:
                continue
            rel = path.relative_to(base).as_posix()
            text = path.read_text(encoding="utf-8", errors="replace")
            imports, symbols = self._extract(path, text)
            risks = tuple(name for name, rx in self.RISK_PATTERNS.items() if rx.search(text))
            kind = self._kind(path, text)
            report.modules.append(ModuleInfo(rel, kind, tuple(sorted(imports)), tuple(sorted(symbols)), risks))
            if risks:
                report.risky_modules.append(rel)
            for imp in imports:
                report.dependency_edges.append((rel, imp))
        report.entrypoints = self._entrypoints(report)
        return report

    def _extract(self, path: Path, text: str) -> tuple[set[str], set[str]]:
        imports: set[str] = set()
        symbols: set[str] = set()
        if path.suffix == ".py":
            try:
                tree = ast.parse(text)
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        imports.update(a.name.split(".")[0] for a in node.names)
                    elif isinstance(node, ast.ImportFrom) and node.module:
                        imports.add(node.module.split(".")[0])
                    elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        symbols.add(node.name)
            except SyntaxError:
                imports.update(re.findall(r"^(?:import|from)\s+([\w.]+)", text, re.M))
        else:
            imports.update(re.findall(r"(?:import|from)\s+[\"']?([\w@./-]+)", text))
            symbols.update(re.findall(r"(?:function|class)\s+(\w+)", text))
        return imports, symbols

    @staticmethod
    def _kind(path: Path, text: str) -> str:
        name = path.name.lower()
        if name in {"main.py", "app.py", "server.py", "index.js", "index.ts", "main.go"}:
            return "entrypoint"
        if "test" in name or path.parent.name.lower() in {"tests", "test"}:
            return "test"
        if "config" in name or "settings" in name:
            return "config"
        return "source"

    @staticmethod
    def _entrypoints(report: ArchitectureReport) -> list[str]:
        explicit = [m.path for m in report.modules if m.kind == "entrypoint"]
        if explicit:
            return explicit
        return [m.path for m in report.modules if Path(m.path).name.startswith("__main__")]
