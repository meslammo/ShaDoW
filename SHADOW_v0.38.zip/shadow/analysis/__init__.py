"""Project architecture analysis primitives."""
from .analyzer import ArchitectureAnalyzer, ArchitectureReport, ModuleInfo

__all__ = ["ArchitectureAnalyzer", "ArchitectureReport", "ModuleInfo"]
