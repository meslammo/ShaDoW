from __future__ import annotations
import importlib
from typing import Any, Callable
from .config import ShadowConfig
from .runtime import ProductionRuntime


def load_factory(spec: str) -> Callable[..., Any]:
    """Load an application factory from ``module:attribute``."""
    if not spec or ":" not in spec:
        raise ValueError("SHADOW_APP_FACTORY must use module:attribute")
    module_name, attr = spec.split(":", 1)
    if not module_name or not attr:
        raise ValueError("invalid application factory")
    module = importlib.import_module(module_name)
    factory = getattr(module, attr, None)
    if not callable(factory):
        raise TypeError(f"application factory is not callable: {spec}")
    return factory


def build_runtime(factory_spec: str | None = None, *, config: ShadowConfig | None = None) -> ProductionRuntime:
    """Build the production runtime from a user-supplied composition factory."""
    cfg = config or ShadowConfig.from_env()
    spec = factory_spec or __import__("os").environ.get("SHADOW_APP_FACTORY")
    if not spec:
        raise RuntimeError("no application factory configured; set SHADOW_APP_FACTORY=module:factory")
    factory = load_factory(spec)
    runtime = factory(config=cfg) if "config" in getattr(factory, "__annotations__", {}) else factory()
    if not isinstance(runtime, ProductionRuntime):
        raise TypeError("application factory must return ProductionRuntime")
    return runtime
