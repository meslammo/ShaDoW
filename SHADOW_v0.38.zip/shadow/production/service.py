from __future__ import annotations
import argparse
import signal
import threading
from .bootstrap import build_runtime


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="shadow", description="Run the SHADOW production runtime")
    parser.add_argument("--no-serve", action="store_true", help="start core without the HTTP gateway")
    args = parser.parse_args(argv)
    runtime = build_runtime()
    stop = threading.Event()

    def handle_signal(signum, _frame):
        runtime.logger.info("shutdown signal received signal=%s", signum)
        stop.set()

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)
    runtime.start(serve=not args.no_serve)
    try:
        while not stop.wait(0.5):
            pass
    finally:
        runtime.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
