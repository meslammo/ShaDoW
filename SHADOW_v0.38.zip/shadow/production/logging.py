from __future__ import annotations
import logging
import sys
from shadow.security.redaction import SecretRedactor

class RedactingFormatter(logging.Formatter):
    def __init__(self, *args, redactor=None, **kwargs):
        super().__init__(*args, **kwargs); self.redactor = redactor or SecretRedactor()
    def format(self, record):
        message = super().format(record)
        return self.redactor.redact(message)

def configure_logging(level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger("shadow")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.propagate = False
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(RedactingFormatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
        logger.addHandler(handler)
    return logger
