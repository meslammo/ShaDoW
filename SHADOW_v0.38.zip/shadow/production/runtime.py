from __future__ import annotations
import asyncio
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from .config import ShadowConfig
from .logging import configure_logging

@dataclass
class RuntimeHealth:
    status: str = "starting"
    started_at: str | None = None
    stopped_at: str | None = None
    requests: int = 0
    failures: int = 0
    components: dict[str, str] = field(default_factory=dict)

class ProductionRuntime:
    """Lifecycle wrapper for the Shadow core and optional HTTP gateway."""
    def __init__(self, runtime, tools, *, config: ShadowConfig | None = None, gateway=None, components=None):
        self.runtime, self.tools = runtime, tools
        self.config = config or ShadowConfig.from_env()
        self.gateway = gateway
        self.components = components or {}
        self.health = RuntimeHealth(components={k: "unknown" for k in self.components})
        self.logger = configure_logging(self.config.log_level)
        self._server = None
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def start(self, *, serve: bool = True):
        with self._lock:
            if self.health.status == "ready": return self
            self.health.status = "starting"
            for name, component in self.components.items():
                try:
                    result = component.start() if hasattr(component, "start") else None
                    if asyncio.iscoroutine(result):
                        asyncio.run(result)
                    self.health.components[name] = "ready"
                except Exception:
                    self.health.components[name] = "failed"
                    self.health.status = "failed"
                    raise
            if serve and self.gateway is not None:
                self._server = self.gateway.make_server(self.config.host, self.config.port)
                self._thread = threading.Thread(target=self._server.serve_forever, name="shadow-gateway", daemon=True)
                self._thread.start()
                self.health.components["gateway"] = "ready"
            self.health.started_at = datetime.now(timezone.utc).isoformat()
            self.health.status = "ready"
            self.logger.info("shadow runtime ready environment=%s host=%s port=%s", self.config.environment, self.config.host, self.config.port)
            return self

    async def run_goal(self, goal: str, *, context: dict[str, Any] | None = None):
        if self.health.status != "ready": raise RuntimeError("Shadow runtime is not ready")
        self.health.requests += 1
        try:
            return await asyncio.wait_for(self.runtime.run_goal(goal, self.tools, context=context), timeout=self.config.request_timeout)
        except Exception:
            self.health.failures += 1
            raise

    def health_snapshot(self) -> dict[str, Any]:
        return {"status": self.health.status, "started_at": self.health.started_at, "stopped_at": self.health.stopped_at,
                "requests": self.health.requests, "failures": self.health.failures, "components": dict(self.health.components)}

    def stop(self):
        with self._lock:
            if self.health.status == "stopped": return
            if self._server is not None:
                self._server.shutdown(); self._server.server_close(); self._server = None
            if self._thread is not None:
                self._thread.join(timeout=self.config.shutdown_timeout); self._thread = None
            for name, component in reversed(list(self.components.items())):
                try:
                    result = component.stop() if hasattr(component, "stop") else None
                    if asyncio.iscoroutine(result): asyncio.run(result)
                    self.health.components[name] = "stopped"
                except Exception:
                    self.health.components[name] = "failed"
            self.health.stopped_at = datetime.now(timezone.utc).isoformat()
            self.health.status = "stopped"
            self.logger.info("shadow runtime stopped")

    def __enter__(self): return self.start()
    def __exit__(self, exc_type, exc, tb): self.stop()
