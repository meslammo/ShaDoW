from __future__ import annotations
from dataclasses import dataclass
import os

@dataclass(frozen=True)
class ShadowConfig:
    host: str = "127.0.0.1"
    port: int = 8787
    gateway_token: str | None = None
    request_timeout: float = 60.0
    shutdown_timeout: float = 10.0
    log_level: str = "INFO"
    environment: str = "production"

    @classmethod
    def from_env(cls, environ: dict[str, str] | None = None) -> "ShadowConfig":
        env = os.environ if environ is None else environ
        def positive_float(name: str, default: float) -> float:
            value = float(env.get(name, default))
            if value <= 0: raise ValueError(f"{name} must be > 0")
            return value
        def positive_int(name: str, default: int) -> int:
            value = int(env.get(name, default))
            if not 1 <= value <= 65535: raise ValueError(f"{name} must be 1..65535")
            return value
        return cls(
            host=env.get("SHADOW_HOST", "127.0.0.1"),
            port=positive_int("SHADOW_PORT", 8787),
            gateway_token=env.get("SHADOW_GATEWAY_TOKEN") or None,
            request_timeout=positive_float("SHADOW_REQUEST_TIMEOUT", 60.0),
            shutdown_timeout=positive_float("SHADOW_SHUTDOWN_TIMEOUT", 10.0),
            log_level=env.get("SHADOW_LOG_LEVEL", "INFO").upper(),
            environment=env.get("SHADOW_ENV", "production"),
        )
