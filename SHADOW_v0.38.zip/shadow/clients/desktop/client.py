from __future__ import annotations
import json
from urllib.request import Request, urlopen
from shadow.clients.gateway.protocol import ClientRequest

class DesktopClient:
    """Dependency-free desktop transport client for the local Shadow gateway."""
    def __init__(self, base_url="http://127.0.0.1:8787", token=None):
        self.base_url, self.token = base_url.rstrip("/"), token
    def request(self, req: ClientRequest, timeout=30):
        headers = {"Content-Type": "application/json"}
        if self.token: headers["Authorization"] = f"Bearer {self.token}"
        body = req.to_json().encode()
        with urlopen(Request(self.base_url + "/v1/request", data=body, headers=headers, method="POST"), timeout=timeout) as r:
            return json.loads(r.read())
    def health(self, timeout=5):
        with urlopen(self.base_url + "/health", timeout=timeout) as r: return json.loads(r.read())
