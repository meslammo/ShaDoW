"""Client-facing transports for Shadow."""
