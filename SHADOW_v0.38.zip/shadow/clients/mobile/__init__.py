"""Mobile client wire contract; platform UI remains separate from the Python core."""
