# Mobile client protocol

Android/iOS clients talk only to the authenticated Shadow Gateway.

- `GET /health`
- `POST /v1/request`
- Header: `Authorization: Bearer <token>` when configured
- Request: `{ "id": "...", "action": "run_goal", "payload": {"goal": "..."}, "context": {} }`
- Response: `{ "id": "...", "ok": true, "data": {...} }`

The mobile client never receives tool credentials and never executes Shadow tools directly.
