from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import json

@dataclass(frozen=True)
class ClientRequest:
    request_id: str
    action: str
    payload: dict[str, Any] = field(default_factory=dict)
    context: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps({"id": self.request_id, "action": self.action,
                           "payload": self.payload, "context": self.context}, separators=(",", ":"))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClientRequest":
        if not isinstance(data.get("id"), str) or not data["id"]:
            raise ValueError("request id is required")
        if not isinstance(data.get("action"), str) or not data["action"]:
            raise ValueError("action is required")
        return cls(data["id"], data["action"], data.get("payload") or {}, data.get("context") or {})

@dataclass(frozen=True)
class ClientResponse:
    request_id: str
    ok: bool
    data: Any = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out = {"id": self.request_id, "ok": self.ok}
        if self.ok: out["data"] = self.data
        else: out["error"] = self.error or "request failed"
        return out
