from __future__ import annotations
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from .protocol import ClientRequest, ClientResponse

class ShadowGateway:
    """Small authenticated HTTP gateway; the client never receives direct tool access."""
    def __init__(self, runtime, tools, *, token: str | None = None):
        self.runtime, self.tools, self.token = runtime, tools, token

    async def handle(self, request: ClientRequest) -> ClientResponse:
        try:
            if request.action == "health":
                return ClientResponse(request.request_id, True, {"status": "ok"})
            if request.action == "run_goal":
                goal = request.payload.get("goal")
                if not isinstance(goal, str) or not goal.strip():
                    raise ValueError("goal is required")
                result = await self.runtime.run_goal(goal, self.tools, context=request.context)
                return ClientResponse(request.request_id, True, {
                    "goal": result.goal, "success": result.success,
                    "decision": getattr(result.decision, "value", result.decision),
                    "steps": [s.__dict__ for s in result.steps], "error": result.error,
                })
            raise ValueError(f"unsupported action: {request.action}")
        except Exception as exc:
            return ClientResponse(request.request_id, False, error=str(exc))

    def make_server(self, host="127.0.0.1", port=8787):
        gateway = self
        class Handler(BaseHTTPRequestHandler):
            def _reply(self, status, body):
                raw = json.dumps(body, ensure_ascii=False).encode()
                self.send_response(status); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            def do_GET(self):
                if self.path != "/health": self._reply(404, {"ok": False, "error": "not found"}); return
                self._reply(200, {"ok": True, "data": {"status": "ok"}})
            def do_POST(self):
                if self.path != "/v1/request": self._reply(404, {"ok": False, "error": "not found"}); return
                if gateway.token and self.headers.get("Authorization") != f"Bearer {gateway.token}":
                    self._reply(401, {"ok": False, "error": "unauthorized"}); return
                try:
                    length = int(self.headers.get("Content-Length", "0")); data = json.loads(self.rfile.read(length))
                    req = ClientRequest.from_dict(data)
                    import asyncio
                    response = asyncio.run(gateway.handle(req))
                    self._reply(200 if response.ok else 400, response.to_dict())
                except Exception as exc: self._reply(400, {"ok": False, "error": str(exc)})
            def log_message(self, *_): return
        return ThreadingHTTPServer((host, port), Handler)
