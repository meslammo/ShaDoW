from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

@dataclass(frozen=True)
class AuditEvent:
    event: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class AuditTrail:
    """Append-only in-memory audit trail for Shadow decisions and actions."""
    def __init__(self):
        self._events: list[AuditEvent] = []

    async def record(self, event: str, *args: Any, **data: Any) -> AuditEvent:
        # Backward-compatible tool audit: record(name, arguments, result).
        if args:
            if len(args) > 2:
                raise TypeError("record accepts at most arguments and result")
            if len(args) >= 1:
                data.setdefault("arguments", args[0])
            if len(args) == 2:
                data.setdefault("result", args[1])
        item = AuditEvent(event, data)
        self._events.append(item)
        return item

    async def record_action(self, action: str, **data: Any) -> AuditEvent:
        return await self.record(action, **data)

    def events(self) -> list[AuditEvent]:
        return list(self._events)
