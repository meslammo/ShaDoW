from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..policy.engine import SolutionCandidate

@dataclass(frozen=True)
class ScoredCandidate:
    candidate: SolutionCandidate
    score: float

class DecisionScorer:
    """Deterministic, explainable scoring with optional learned confidence."""
    def __init__(self, learning=None):
        self.learning = learning

    def score(self, candidate: SolutionCandidate) -> float:
        license_score = 1.0 if candidate.license else 0.0
        compatibility = 1.0 if candidate.compatible else 0.0
        base = 0.35*candidate.quality + 0.25*candidate.completeness + 0.20*compatibility + 0.20*license_score
        adjustment = self.learning.adjustment(candidate.source) if self.learning is not None else 0.0
        return round(max(0.0, min(1.0, base + adjustment)), 4)

    def rank(self, candidates: Iterable[SolutionCandidate]) -> list[ScoredCandidate]:
        ranked = [ScoredCandidate(c, self.score(c)) for c in candidates]
        return sorted(ranked, key=lambda x: x.score, reverse=True)
