from __future__ import annotations

from dataclasses import dataclass
from importlib import metadata
from pathlib import PurePosixPath
from typing import Iterable
from urllib.parse import urlparse

import httpx
from packaging.requirements import Requirement
from packaging.version import Version


@dataclass(frozen=True)
class DependencyResult:
    name: str
    required: str
    installed: str | None
    satisfied: bool
    reason: str


@dataclass(frozen=True)
class DependencyVerification:
    verified: bool
    dependencies: tuple[DependencyResult, ...]
    source: str
    reason: str = ""


class DependencyVerifier:
    """Verify declared Python dependencies and local version compatibility."""

    def __init__(self, *, timeout: float = 10.0, check_local: bool = True):
        self.timeout = timeout
        self.check_local = check_local

    @staticmethod
    def parse_requirements(text: str) -> list[str]:
        requirements: list[str] = []
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            if " #" in line:
                line = line.split(" #", 1)[0].strip()
            try:
                Requirement(line)
            except Exception:
                continue
            requirements.append(line)
        return requirements

    @staticmethod
    def _local_result(spec: str) -> DependencyResult:
        req = Requirement(spec)
        try:
            installed = metadata.version(req.name)
        except metadata.PackageNotFoundError:
            return DependencyResult(req.name, spec, None, False, "package not installed")
        try:
            ok = not req.specifier or Version(installed) in req.specifier
        except Exception:
            ok = False
        return DependencyResult(req.name, spec, installed, ok, "version satisfies requirement" if ok else "installed version does not satisfy requirement")

    def verify_requirements(self, requirements: Iterable[str], *, source: str = "local") -> DependencyVerification:
        results: list[DependencyResult] = []
        for spec in requirements:
            if self.check_local:
                results.append(self._local_result(spec))
            else:
                req = Requirement(spec)
                results.append(DependencyResult(req.name, spec, None, True, "declaration parsed"))
        return DependencyVerification(
            verified=all(r.satisfied for r in results),
            dependencies=tuple(results),
            source=source,
            reason="all dependencies satisfied" if all(r.satisfied for r in results) else "one or more dependencies are unsatisfied",
        )

    @staticmethod
    def _github_repo(location: str) -> tuple[str, str] | None:
        parsed = urlparse(location)
        if parsed.netloc.lower() not in {"github.com", "www.github.com"}:
            return None
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) < 2:
            return None
        return parts[0], parts[1].removesuffix(".git")

    async def verify_repository(self, location: str) -> DependencyVerification:
        repo = self._github_repo(location)
        if not repo:
            return DependencyVerification(False, (), location, "only GitHub repository URLs are supported")
        owner, name = repo
        headers = {"User-Agent": "Shadow/0.11"}
        async with httpx.AsyncClient(timeout=self.timeout, headers=headers, follow_redirects=True) as client:
            for filename in ("pyproject.toml", "requirements.txt", "requirements/base.txt", "requirements.txt"):
                url = f"https://raw.githubusercontent.com/{owner}/{name}/HEAD/{filename}"
                try:
                    response = await client.get(url)
                    if not response.is_success:
                        continue
                    text = response.text
                    if PurePosixPath(filename).name == "pyproject.toml":
                        requirements = self._parse_pyproject(text)
                    else:
                        requirements = self.parse_requirements(text)
                    if requirements:
                        return self.verify_requirements(requirements, source=url)
                except httpx.HTTPError:
                    continue
        return DependencyVerification(False, (), location, "no supported dependency manifest found")

    @staticmethod
    def _parse_pyproject(text: str) -> list[str]:
        try:
            import tomllib
            data = tomllib.loads(text)
        except Exception:
            return []
        project = data.get("project", {})
        deps = list(project.get("dependencies", []) or [])
        for group in (data.get("project", {}).get("optional-dependencies", {}) or {}).values():
            deps.extend(group or [])
        return [d for d in deps if isinstance(d, str)]
