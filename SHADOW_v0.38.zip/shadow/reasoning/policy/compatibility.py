from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import platform
import re
import sys
from typing import Any

from packaging.specifiers import SpecifierSet


@dataclass(frozen=True)
class CompatibilityCheck:
    compatible: bool
    target: str
    current: str | None
    reason: str


@dataclass(frozen=True)
class CompatibilityReport:
    compatible: bool
    checks: tuple[CompatibilityCheck, ...]


class CompatibilityEngine:
    """Fail-closed compatibility checks for Python projects and host OS."""

    def __init__(self, *, python_version: str | None = None, system: str | None = None):
        self.python_version = python_version or platform.python_version()
        self.system = (system or platform.system()).lower()

    def check_python(self, requirement: str | None) -> CompatibilityCheck:
        if not requirement:
            return CompatibilityCheck(True, "python", self.python_version, "no Python requirement declared")
        try:
            ok = self.python_version in SpecifierSet(requirement)
        except Exception as exc:
            return CompatibilityCheck(False, f"python {requirement}", self.python_version, f"invalid Python requirement: {exc}")
        return CompatibilityCheck(ok, f"python {requirement}", self.python_version,
                                  "Python version satisfies requirement" if ok else "Python version does not satisfy requirement")

    def check_os(self, supported: list[str] | tuple[str, ...] | None) -> CompatibilityCheck:
        if not supported:
            return CompatibilityCheck(True, "os", self.system, "no OS restriction declared")
        normalized = {self._normalize_os(x) for x in supported}
        ok = self.system in normalized
        return CompatibilityCheck(ok, f"os in {sorted(normalized)}", self.system,
                                  "host OS is supported" if ok else "host OS is not supported")

    @staticmethod
    def _normalize_os(value: str) -> str:
        value = value.strip().lower()
        aliases = {"windows": "windows", "win32": "windows", "darwin": "darwin", "macos": "darwin",
                   "mac": "darwin", "linux": "linux"}
        return aliases.get(value, value)

    @staticmethod
    def _extract_python_requirement(text: str) -> str | None:
        # Supports common pyproject forms: requires-python = ">=3.11"
        match = re.search(r"requires-python\s*=\s*['\"]([^'\"]+)['\"]", text, re.I)
        return match.group(1).strip() if match else None

    @staticmethod
    def _extract_os(text: str) -> list[str] | None:
        # Deliberately conservative: only explicit simple OS markers are accepted.
        found = re.findall(r"\b(windows|linux|darwin|macos|mac)\b", text, re.I)
        return sorted({x.lower() for x in found}) or None

    def verify_project_text(self, text: str, *, source: str = "project") -> CompatibilityReport:
        checks = [self.check_python(self._extract_python_requirement(text))]
        checks.append(self.check_os(self._extract_os(text)))
        return CompatibilityReport(all(c.compatible for c in checks), tuple(checks))

    def verify_path(self, path: str | Path) -> CompatibilityReport:
        p = Path(path)
        if not p.is_file():
            return CompatibilityReport(False, (CompatibilityCheck(False, "project file", None, "path is not a file"),))
        try:
            text = p.read_text(encoding="utf-8")
        except OSError as exc:
            return CompatibilityReport(False, (CompatibilityCheck(False, "project file", None, f"read failed: {exc}"),))
        return self.verify_project_text(text, source=str(p))
