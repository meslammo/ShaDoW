from __future__ import annotations

from typing import Any
import httpx

from .engine import SolutionCandidate


class GitHubSolutionDiscovery:
    """Discover licensed GitHub repositories for a goal via the public API."""

    def __init__(self, *, token: str | None = None, timeout: float = 10.0, max_results: int = 8):
        self.token = token
        self.timeout = timeout
        self.max_results = max_results

    async def search(self, goal: str, context: dict[str, Any] | None = None) -> list[SolutionCandidate]:
        context = context or {}
        query = str(context.get("search_query") or goal).strip()
        if not query:
            return []

        headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        params = {"q": query, "sort": "stars", "order": "desc", "per_page": self.max_results}
        async with httpx.AsyncClient(timeout=self.timeout, headers=headers) as client:
            response = await client.get("https://api.github.com/search/repositories", params=params)
            response.raise_for_status()
            payload = response.json()

        candidates: list[SolutionCandidate] = []
        for repo in payload.get("items", []):
            license_info = repo.get("license") or {}
            spdx = license_info.get("spdx_id")
            stars = int(repo.get("stargazers_count") or 0)
            forks = int(repo.get("forks_count") or 0)
            # Bounded heuristics: popularity is evidence, not proof of quality.
            quality = min(1.0, (stars ** 0.5) / 100.0 + min(forks, 1000) / 5000.0)
            completeness = 0.75 if repo.get("description") else 0.55
            if repo.get("has_wiki") or repo.get("has_issues"):
                completeness = min(1.0, completeness + 0.05)
            candidates.append(
                SolutionCandidate(
                    source=repo.get("full_name", ""),
                    module=query,
                    location=repo.get("html_url", ""),
                    license=spdx,
                    dependencies=(),
                    quality=quality,
                    completeness=completeness,
                    compatible=not bool(repo.get("archived")),
                    notes=repo.get("description") or "",
                )
            )
        return candidates
