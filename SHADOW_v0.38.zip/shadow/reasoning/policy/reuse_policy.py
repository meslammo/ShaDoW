from enum import Enum

class Decision(str, Enum):
    REUSE = "reuse"
    MODIFY = "modify"
    INTEGRATE = "integrate"
    BUILD = "build"

def decide(*, existing_good: bool, existing_incomplete: bool,
           open_source_available: bool) -> Decision:
    if existing_good:
        return Decision.REUSE
    if existing_incomplete:
        return Decision.MODIFY
    if open_source_available:
        return Decision.INTEGRATE
    return Decision.BUILD
