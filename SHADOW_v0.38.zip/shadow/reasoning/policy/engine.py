from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from .reuse_policy import Decision


@dataclass(frozen=True)
class SolutionCandidate:
    """A discovered existing solution that Shadow can evaluate before building."""
    source: str
    module: str
    location: str
    license: str | None = None
    dependencies: tuple[str, ...] = ()
    quality: float = 0.0
    completeness: float = 0.0
    compatible: bool = True
    notes: str = ""


class SolutionDiscovery(Protocol):
    async def search(self, goal: str, context: dict[str, Any] | None = None) -> list[SolutionCandidate]: ...


@dataclass
class DecisionRecord:
    goal: str
    decision: Decision
    candidate: SolutionCandidate | None = None
    reason: str = ""


@dataclass
class ReasoningPolicyEngine:
    """Search first, evaluate candidates, then choose reuse/modify/integrate/build."""
    discovery: SolutionDiscovery
    minimum_quality: float = 0.70
    minimum_completeness: float = 0.80
    history: list[DecisionRecord] = field(default_factory=list)

    async def decide(self, goal: str, context: dict[str, Any] | None = None) -> DecisionRecord:
        candidates = await self.discovery.search(goal, context)
        usable = [c for c in candidates if c.compatible and c.license]
        usable.sort(key=lambda c: (c.quality, c.completeness), reverse=True)

        if not usable:
            record = DecisionRecord(goal, Decision.BUILD, reason="no compatible licensed solution found")
        else:
            best = usable[0]
            if best.quality >= self.minimum_quality and best.completeness >= self.minimum_completeness:
                decision = Decision.REUSE
                reason = "existing solution is good enough"
            elif best.quality >= self.minimum_quality or best.completeness >= self.minimum_completeness:
                decision = Decision.MODIFY
                reason = "existing solution is usable but incomplete"
            else:
                decision = Decision.INTEGRATE
                reason = "licensed open-source solution is available but not sufficient alone"
            record = DecisionRecord(goal, decision, best, reason)

        self.history.append(record)
        return record
