from __future__ import annotations

from html.parser import HTMLParser
import re
from typing import Any
from urllib.parse import urlencode

import httpx

from .engine import SolutionCandidate


_LICENSE_PATTERNS = (
    ("Apache-2.0", re.compile(r"apache(?:\s+license)?\s*2(?:\.0)?", re.I)),
    ("MIT", re.compile(r"\bMIT\s+License\b", re.I)),
    ("BSD-3-Clause", re.compile(r"BSD\s*3[- ]Clause", re.I)),
    ("BSD-2-Clause", re.compile(r"BSD\s*2[- ]Clause", re.I)),
    ("MPL-2.0", re.compile(r"Mozilla\s+Public\s+License\s*2(?:\.0)?", re.I)),
    ("GPL-3.0", re.compile(r"GNU\s+General\s+Public\s+License\s*v?3", re.I)),
    ("GPL-2.0", re.compile(r"GNU\s+General\s+Public\s+License\s*v?2", re.I)),
)


class _DuckDuckGoParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.results: list[tuple[str, str, str]] = []
        self._href = ""
        self._title = ""
        self._snippet = ""
        self._in_result = False
        self._in_title = False
        self._in_snippet = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr = dict(attrs)
        classes = attr.get("class", "") or ""
        if tag == "a" and "result__a" in classes:
            if self._in_result and self._title:
                self.results.append((self._title.strip(), self._href, self._snippet.strip()))
            self._in_result = True
            self._in_title = True
            self._href = attr.get("href", "") or ""
            self._title = ""
            self._snippet = ""
        elif self._in_result and tag in {"a", "div"} and "result__snippet" in classes:
            self._in_snippet = True

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self._title += data
        if self._in_snippet:
            self._snippet += data

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._in_title:
            self._in_title = False
        if self._in_snippet and tag in {"a", "div"}:
            self._in_snippet = False
        # Keep the result open while its snippet is parsed; finalize on the next result
        # or at end-of-document.

    def close(self) -> None:
        super().close()
        if self._in_result and self._title:
            self.results.append((self._title.strip(), self._href, self._snippet.strip()))
            self._in_result = False


class WebSolutionDiscovery:
    """Discover candidate projects/pages through DuckDuckGo HTML search.

    This provider intentionally does not claim a license unless the search result
    itself contains an explicit, recognized license name. The policy engine can
    therefore fail closed instead of treating an unknown web result as reusable.
    """

    def __init__(self, *, timeout: float = 10.0, max_results: int = 8, user_agent: str = "Shadow/0.9"):
        self.timeout = timeout
        self.max_results = max_results
        self.user_agent = user_agent

    async def search(self, goal: str, context: dict[str, Any] | None = None) -> list[SolutionCandidate]:
        context = context or {}
        query = str(context.get("web_search_query") or goal).strip()
        if not query:
            return []

        # Bias discovery toward reusable software without pretending every result is code.
        search_query = context.get("web_query_prefix", "open source")
        if search_query:
            query = f"{search_query} {query}"

        params = urlencode({"q": query, "ia": "web"})
        url = f"https://html.duckduckgo.com/html/?{params}"
        headers = {"User-Agent": self.user_agent, "Accept": "text/html"}
        async with httpx.AsyncClient(timeout=self.timeout, headers=headers, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()

        parser = _DuckDuckGoParser()
        parser.feed(response.text)
        parser.close()
        candidates: list[SolutionCandidate] = []
        for title, location, snippet in parser.results[: self.max_results]:
            combined = f"{title} {snippet}"
            license_name = next((name for name, pattern in _LICENSE_PATTERNS if pattern.search(combined)), None)
            quality = 0.55
            if "github.com" in location.lower():
                quality += 0.15
            if license_name:
                quality += 0.10
            if any(word in combined.lower() for word in ("documentation", "repository", "source code", "open source")):
                quality += 0.05
            quality = min(1.0, quality)
            completeness = 0.50 + (0.20 if license_name else 0.0) + (0.10 if snippet else 0.0)
            candidates.append(
                SolutionCandidate(
                    source=title,
                    module=query,
                    location=location,
                    license=license_name,
                    dependencies=(),
                    quality=quality,
                    completeness=min(1.0, completeness),
                    compatible=True,
                    notes=snippet,
                )
            )
        return candidates
