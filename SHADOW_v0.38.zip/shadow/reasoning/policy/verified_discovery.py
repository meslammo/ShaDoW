from __future__ import annotations

from typing import Any

from .engine import SolutionCandidate, SolutionDiscovery
from .license_verifier import LicenseVerifier

class VerifiedSolutionDiscovery:
    """Wrap any discovery provider and replace unverified license claims with verified evidence."""
    def __init__(self, discovery: SolutionDiscovery, verifier: LicenseVerifier | None = None):
        self.discovery = discovery
        self.verifier = verifier or LicenseVerifier()

    async def search(self, goal: str, context: dict[str, Any] | None = None) -> list[SolutionCandidate]:
        candidates = await self.discovery.search(goal, context)
        verified: list[SolutionCandidate] = []
        for candidate in candidates:
            result = await self.verifier.verify(candidate.location, candidate.license)
            verified.append(SolutionCandidate(
                source=candidate.source,
                module=candidate.module,
                location=candidate.location,
                license=result.license if result.verified else None,
                dependencies=candidate.dependencies,
                quality=candidate.quality,
                completeness=min(1.0, candidate.completeness + (0.10 if result.verified else 0.0)),
                compatible=candidate.compatible and result.verified,
                notes=(candidate.notes + " | license: " + result.reason).strip(" |"),
            ))
        return verified
