from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx

LICENSE_PATTERNS = (
    ("Apache-2.0", re.compile(r"Apache License(?:,? Version)?\s*2(?:\.0)?|Apache-2\.0", re.I)),
    ("MIT", re.compile(r"MIT License|Permission is hereby granted, free of charge", re.I)),
    ("BSD-3-Clause", re.compile(r"BSD\s*3[- ]Clause|Redistribution and use in source and binary forms", re.I)),
    ("BSD-2-Clause", re.compile(r"BSD\s*2[- ]Clause", re.I)),
    ("MPL-2.0", re.compile(r"Mozilla Public License\s*2(?:\.0)?|MPL-2\.0", re.I)),
    ("GPL-3.0", re.compile(r"GNU General Public License.*v?3|GPL-3\.0", re.I | re.S)),
    ("GPL-2.0", re.compile(r"GNU General Public License.*v?2|GPL-2\.0", re.I | re.S)),
)

@dataclass(frozen=True)
class LicenseVerification:
    license: str | None
    verified: bool
    source: str
    reason: str = ""

class LicenseVerifier:
    """Fail-closed license verifier for GitHub repositories and public web pages."""
    def __init__(self, *, timeout: float = 10.0, user_agent: str = "Shadow/0.10"):
        self.timeout = timeout
        self.user_agent = user_agent

    @staticmethod
    def _detect(text: str) -> str | None:
        for name, pattern in LICENSE_PATTERNS:
            if pattern.search(text):
                return name
        return None

    @staticmethod
    def _github_repo(url: str) -> tuple[str, str] | None:
        parsed = urlparse(url)
        if parsed.netloc.lower() not in {"github.com", "www.github.com"}:
            return None
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) < 2:
            return None
        return parts[0], parts[1].removesuffix(".git")

    async def verify(self, location: str, claimed_license: str | None = None) -> LicenseVerification:
        repo = self._github_repo(location)
        headers = {"User-Agent": self.user_agent, "Accept": "application/vnd.github+json"}
        async with httpx.AsyncClient(timeout=self.timeout, headers=headers, follow_redirects=True) as client:
            if repo:
                owner, name = repo
                api = f"https://api.github.com/repos/{owner}/{name}/license"
                try:
                    response = await client.get(api)
                    if response.is_success:
                        payload: dict[str, Any] = response.json()
                        spdx = (payload.get("license") or {}).get("spdx_id")
                        if spdx:
                            return LicenseVerification(spdx, True, api, "GitHub license endpoint")
                except httpx.HTTPError:
                    pass
                # Fallback to the repository LICENSE file if the endpoint is unavailable.
                for filename in ("LICENSE", "LICENSE.md", "LICENSE.txt"):
                    try:
                        response = await client.get(f"https://raw.githubusercontent.com/{owner}/{name}/HEAD/{filename}")
                        if response.is_success:
                            detected = self._detect(response.text)
                            if detected:
                                return LicenseVerification(detected, True, response.url.__str__(), "LICENSE file")
                    except httpx.HTTPError:
                        continue
                return LicenseVerification(None, False, location, "GitHub license could not be verified")

            try:
                response = await client.get(location)
                response.raise_for_status()
                detected = self._detect(response.text)
                if detected:
                    return LicenseVerification(detected, True, str(response.url), "license text found on page")
            except httpx.HTTPError as exc:
                return LicenseVerification(None, False, location, f"fetch failed: {exc}")
            return LicenseVerification(None, False, location, "no recognized license text found")
