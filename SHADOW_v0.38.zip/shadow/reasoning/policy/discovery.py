from __future__ import annotations

from typing import Any, Iterable

from .engine import SolutionCandidate, SolutionDiscovery


class CompositeSolutionDiscovery:
    """Run multiple discovery providers and merge candidates without duplicate sources."""

    def __init__(self, providers: Iterable[SolutionDiscovery]):
        self.providers = tuple(providers)

    async def search(self, goal: str, context: dict[str, Any] | None = None) -> list[SolutionCandidate]:
        merged: dict[tuple[str, str], SolutionCandidate] = {}
        for provider in self.providers:
            for candidate in await provider.search(goal, context):
                key = (candidate.source, candidate.module)
                previous = merged.get(key)
                if previous is None or (candidate.quality, candidate.completeness) > (previous.quality, previous.completeness):
                    merged[key] = candidate
        return sorted(merged.values(), key=lambda c: (c.quality, c.completeness), reverse=True)
