from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True)
class HealingAttempt:
    attempt: int
    success: bool
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class HealingResult:
    success: bool
    attempts: tuple[HealingAttempt, ...]
    final_error: str | None = None


class SelfHealingEngine:
    """Bounded retry/repair loop that never bypasses safety gates.

    ``repair`` receives the failed result and may make a conservative change.
    The engine itself does not execute arbitrary code; callers decide what a
    repair operation is and should route risky actions through Shadow's
    execution gateway.
    """

    def __init__(self, *, max_attempts: int = 2):
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        self.max_attempts = max_attempts

    def run(
        self,
        operation: Callable[[], Any],
        *,
        repair: Callable[[Any], Any] | None = None,
        success: Callable[[Any], bool] | None = None,
    ) -> HealingResult:
        check = success or (lambda value: bool(value))
        attempts: list[HealingAttempt] = []
        last_error: str | None = None
        for number in range(1, self.max_attempts + 1):
            try:
                result = operation()
                ok = bool(check(result))
                attempts.append(HealingAttempt(number, ok, None if ok else "operation reported failure"))
                if ok:
                    return HealingResult(True, tuple(attempts))
                last_error = "operation reported failure"
                if repair is None or number >= self.max_attempts:
                    break
                repair(result)
            except Exception as exc:
                last_error = str(exc)
                attempts.append(HealingAttempt(number, False, last_error))
                if repair is None or number >= self.max_attempts:
                    break
                repair(exc)
        return HealingResult(False, tuple(attempts), last_error)
    async def async_run(
        self,
        operation,
        *,
        repair=None,
        success=None,
    ) -> HealingResult:
        """Async counterpart for agent/tool operations; keeps the same bounded contract."""
        import inspect

        async def maybe(fn, *args):
            value = fn(*args)
            return await value if inspect.isawaitable(value) else value

        check = success or (lambda value: bool(value))
        attempts: list[HealingAttempt] = []
        last_error: str | None = None
        for number in range(1, self.max_attempts + 1):
            try:
                result = await maybe(operation)
                ok = bool(await maybe(check, result))
                attempts.append(HealingAttempt(number, ok, None if ok else "operation reported failure"))
                if ok:
                    return HealingResult(True, tuple(attempts))
                last_error = "operation reported failure"
                if repair is None or number >= self.max_attempts:
                    break
                await maybe(repair, result)
            except Exception as exc:
                last_error = str(exc)
                attempts.append(HealingAttempt(number, False, last_error))
                if repair is None or number >= self.max_attempts:
                    break
                await maybe(repair, exc)
        return HealingResult(False, tuple(attempts), last_error)

