from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class LearningExperience:
    goal: str
    source: str
    decision: str
    success: bool
    metadata: dict[str, Any] = field(default_factory=dict)

class LearningLoop:
    """Small, deterministic feedback loop for improving future solution choices."""
    def __init__(self):
        self._experiences: list[LearningExperience] = []

    async def record(self, experience: LearningExperience) -> None:
        self._experiences.append(experience)

    def experiences(self) -> list[LearningExperience]:
        return list(self._experiences)

    def success_rate(self, source: str | None = None) -> float:
        items = [e for e in self._experiences if source is None or e.source == source]
        if not items:
            return 0.0
        return round(sum(e.success for e in items) / len(items), 4)

    def adjustment(self, source: str) -> float:
        """Return a bounded confidence adjustment based only on observed outcomes."""
        rate = self.success_rate(source)
        if not any(e.source == source for e in self._experiences):
            return 0.0
        return round((rate - 0.5) * 0.20, 4)

    async def learn_from_decision(self, record: Any, success: bool, **metadata: Any) -> LearningExperience:
        candidate = getattr(record, "candidate", None)
        source = getattr(candidate, "source", "unknown")
        decision = getattr(getattr(record, "decision", None), "value", getattr(record, "decision", "unknown"))
        exp = LearningExperience(
            goal=getattr(record, "goal", ""), source=source,
            decision=str(decision), success=bool(success), metadata=metadata,
        )
        await self.record(exp)
        return exp
