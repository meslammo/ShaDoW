from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable
import inspect

from shadow.recovery.healing import SelfHealingEngine


@dataclass(frozen=True)
class AgentStepResult:
    index: int
    intent: str
    observation: Any = None
    accepted: bool = False
    reason: str = ""
    attempts: int = 1


@dataclass(frozen=True)
class AgentRunResult:
    goal: str
    success: bool
    steps: tuple[AgentStepResult, ...] = ()
    decision: Any = None
    error: str | None = None
    events: tuple[str, ...] = ()


class AutonomousAgentLoop:
    """Bounded Goal -> Plan -> Execute -> Critic -> Repair -> Verify -> Learn loop.

    The loop delegates risky execution to the supplied executor and never executes
    tool objects directly. Policy, memory, audit, and learning are optional hooks.
    """

    def __init__(self, planner, critic, executor, *, policy=None, memory=None,
                 verifier=None, healer=None, learner=None, audit=None,
                 max_step_retries: int = 2, max_replans: int = 1):
        if max_step_retries < 1:
            raise ValueError("max_step_retries must be >= 1")
        self.planner = planner
        self.critic = critic
        self.executor = executor
        self.policy = policy
        self.memory = memory
        self.verifier = verifier
        self.healer = healer or SelfHealingEngine(max_attempts=max_step_retries)
        self.learner = learner
        self.audit = audit
        if max_replans < 0:
            raise ValueError("max_replans must be >= 0")
        self.max_step_retries = max_step_retries
        self.max_replans = max_replans

    async def _maybe(self, fn: Callable, *args, **kwargs):
        value = fn(*args, **kwargs)
        return await value if inspect.isawaitable(value) else value

    async def _audit(self, event: str, **data):
        if self.audit is not None:
            await self.audit.record_action(event, **data)

    async def run(self, goal: str, tools: dict[str, object] | list[object], *, context=None) -> AgentRunResult:
        events: list[str] = []
        step_results: list[AgentStepResult] = []
        decision = None
        try:
            manifest = ([{"name": k, "risky": bool(getattr(v, "risky", False))} for k, v in tools.items()]
                        if isinstance(tools, dict) else
                        [{"name": getattr(t, "name", str(i)), "risky": bool(getattr(t, "risky", False))}
                         for i, t in enumerate(tools)])

            if self.policy is not None:
                decision = await self._maybe(self.policy.decide, goal, context)
                events.append("decision")
                await self._audit("agent.decision", goal=goal, decision=str(decision))

            current_goal = goal
            replans = 0
            memory_context = None
            if self.memory is not None and hasattr(self.memory, "recall_context"):
                memory_context = await self.memory.recall_context(goal, limit=5)
                if memory_context:
                    events.append("memory-recalled")
                    await self._audit("agent.memory_recalled", goal=goal, count=len(memory_context.split("\n\n")))

            completed_steps = 0
            while True:
                planning_context = context.copy() if isinstance(context, dict) else {}
                if memory_context:
                    planning_context["memory_context"] = memory_context
                planning_goal = current_goal
                if planning_context:
                    planning_goal = f"{current_goal}\nContext: {planning_context}"
                plan = await self.planner.plan(planning_goal, manifest)
                events.append("planned" if replans == 0 else "replanned")
                await self._audit("agent.replanned" if replans else "agent.planned",
                                   goal=goal, planning_goal=current_goal, steps=len(plan.steps), replans=replans)

                failed_step = None
                for step in plan.steps:
                    async def attempt():
                        last = None
                        for call in step.tool_calls:
                            if isinstance(tools, dict):
                                if call.tool not in tools:
                                    raise KeyError(f"unknown tool: {call.tool}")
                                tool = tools[call.tool]
                            else:
                                tool = next((t for t in tools if getattr(t, "name", None) == call.tool), None)
                                if tool is None:
                                    raise KeyError(f"unknown tool: {call.tool}")
                            last = await self.executor.execute(
                                tool, call.arguments,
                                risky=bool(getattr(tool, "risky", False)),
                                context={"goal": goal, "step": step.intent, **(context or {})},
                            )
                        verdict = await self.critic.evaluate(step, last)
                        if verdict.accept and self.verifier is not None:
                            verified = await self._maybe(self.verifier, step, last)
                            if not verified:
                                verdict.accept = False
                                verdict.reason = verdict.reason or "verification failed"
                        return last, verdict

                    async def operation():
                        return await attempt()

                    # Healing only retries a failed critic/verification result; exceptions
                    # are still bounded and remain subject to the executor's safety gate.
                    holder = {"value": None}
                    async def op_with_holder():
                        value = await operation()
                        holder["value"] = value
                        return value

                    def success(value):
                        return bool(value and value[1].accept)

                    async def repair(value):
                        if self.audit is not None:
                            await self.audit.record_action("agent.repair_requested", goal=goal, step=step.intent,
                                                           reason=str(value))

                    healing = await self._run_healing(op_with_holder, repair, success)
                    observation, verdict = holder["value"] or (None, None)
                    accepted = bool(verdict and verdict.accept and healing.success)
                    reason = verdict.reason if verdict else (healing.final_error or "step failed")
                    attempts = len(healing.attempts)
                    step_results.append(AgentStepResult(step.index, step.intent, observation, accepted, reason, attempts))
                    events.append("step-passed" if accepted else "step-failed")
                    await self._audit("agent.step", goal=goal, step=step.intent, accepted=accepted, attempts=attempts,
                                       reason=reason)
                    if self.memory is not None:
                        await self.memory.add_result(goal=goal, step=step.intent, result=observation,
                                                     verdict=verdict)
                    if self.learner is not None and decision is not None:
                        await self.learner.learn_from_decision(decision, accepted, step=step.intent, attempts=attempts)
                    if not accepted:
                        failed_step = (step, reason)
                        break

                if failed_step is None:
                    break
                if replans >= self.max_replans:
                    step, reason = failed_step
                    if self.memory is not None and hasattr(self.memory, "add_run"):
                        await self.memory.add_run(goal=goal, success=False, steps=len(step_results), decision=decision)
                    return AgentRunResult(goal, False, tuple(step_results), decision,
                                          error=reason, events=tuple(events))
                step, reason = failed_step
                replans += 1
                current_goal = (
                    f"{goal}\nRepair failed step {step.index} ({step.intent}). "
                    f"Reason: {reason}. Replan using the available tools and avoid repeating the same failed approach."
                )
                await self._audit("agent.replan_requested", goal=goal, step=step.intent,
                                   reason=reason, replan=replans)
            events.append("completed")
            await self._audit("agent.completed", goal=goal, steps=len(step_results))
            if self.memory is not None and hasattr(self.memory, "add_run"):
                await self.memory.add_run(goal=goal, success=True, steps=len(step_results), decision=decision)
            return AgentRunResult(goal, True, tuple(step_results), decision, events=tuple(events))
        except Exception as exc:
            events.append("failed")
            await self._audit("agent.failed", goal=goal, error=str(exc))
            return AgentRunResult(goal, False, tuple(step_results), decision, error=str(exc), events=tuple(events))

    async def _run_healing(self, operation, repair, success):
        if hasattr(self.healer, "async_run"):
            return await self.healer.async_run(operation, repair=repair, success=success)

        # Backward-compatible fallback for custom synchronous healing engines.
        attempts = []
        last_error = None
        for number in range(1, self.max_step_retries + 1):
            try:
                result = await operation()
                ok = bool(success(result))
                attempts.append((number, ok))
                if ok:
                    return type("Healing", (), {"success": True, "attempts": tuple(attempts), "final_error": None})()
                last_error = "operation reported failure"
                if number < self.max_step_retries:
                    await repair(result)
            except Exception as exc:
                attempts.append((number, False))
                last_error = str(exc)
                if number < self.max_step_retries:
                    await repair(exc)
        return type("Healing", (), {"success": False, "attempts": tuple(attempts), "final_error": last_error})()
