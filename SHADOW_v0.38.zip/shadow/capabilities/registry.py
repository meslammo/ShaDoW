from __future__ import annotations
from dataclasses import dataclass, field

@dataclass(frozen=True)
class Capability:
    name: str
    description: str = ""
    provider: str = "core"
    enabled: bool = True

@dataclass
class CapabilityRegistry:
    _items: dict[str, Capability] = field(default_factory=dict)

    def register(self, capability: Capability) -> None:
        self._items[capability.name] = capability

    def has(self, name: str) -> bool:
        item = self._items.get(name)
        return bool(item and item.enabled)

    def get(self, name: str) -> Capability | None:
        return self._items.get(name)

    def missing(self, names: list[str]) -> list[str]:
        return [name for name in names if not self.has(name)]

    def list(self) -> list[Capability]:
        return list(self._items.values())
