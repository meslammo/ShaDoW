class PersonalJarvisBrowserAdapter:
    """Adapter boundary for the isolated browser-use runner."""
    def __init__(self, runner=None):
        self.runner = runner

    async def run(self, task: str):
        if self.runner is None:
            raise RuntimeError("Browser runner is not connected")
        return await self.runner(task)
