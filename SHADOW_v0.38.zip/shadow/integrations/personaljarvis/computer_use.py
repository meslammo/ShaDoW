class PersonalJarvisComputerUseAdapter:
    """Adapter boundary for PersonalJarvis CU v2 perceive-act-verify engine."""
    def __init__(self, engine=None):
        self.engine = engine

    async def run(self, goal: str):
        if self.engine is None:
            raise RuntimeError("PersonalJarvis CU v2 engine is not connected")
        return await self.engine(goal)
