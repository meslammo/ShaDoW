class PersonalJarvisVoiceAdapter:
    """Lazy adapter to PersonalJarvis' real audio capture stack."""
    def __init__(self):
        try:
            from jarvis.audio import capture
        except ImportError as exc:
            raise RuntimeError("PersonalJarvis is not installed") from exc
        self.capture = capture

    def contract(self) -> dict:
        return {
            "sample_rate": self.capture.SAMPLE_RATE,
            "channels": self.capture.CHANNELS,
            "dtype": self.capture.DTYPE,
            "blocksize": self.capture.BLOCKSIZE,
        }
