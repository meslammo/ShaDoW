from .adapter import ScreenAdapter, ScreenFrame

__all__ = ["ScreenAdapter", "ScreenFrame"]
