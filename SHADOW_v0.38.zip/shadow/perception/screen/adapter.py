from __future__ import annotations
import asyncio, base64, json, os
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

@dataclass(frozen=True)
class ScreenFrame:
    image: bytes | str | None
    width: int | None = None
    height: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

class ScreenAdapter:
    """Provider-neutral screen capture; supports an isolated JSONL capture process."""
    name = "screen"
    risky = False
    def __init__(self, runner: Callable[[], Awaitable[Any]] | None = None,
                 command: list[str] | None = None, *, cwd=None, env=None, timeout=30.0):
        self._runner, self.command, self.cwd, self.env, self.timeout = runner, command, cwd, env, timeout

    def bind(self, runner): self._runner = runner; return self

    async def capture(self) -> ScreenFrame:
        if self._runner:
            result = self._runner(); result = await result if hasattr(result, "__await__") else result
        else:
            if not self.command: raise RuntimeError("screen capture runner is not configured")
            env = os.environ.copy(); env.update(self.env or {})
            proc = await asyncio.create_subprocess_exec(*self.command, stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=self.cwd, env=env)
            out, err = await asyncio.wait_for(proc.communicate(b"{}\n"), self.timeout)
            if proc.returncode != 0: raise RuntimeError(f"screen runner failed: {err.decode(errors='replace')[-4000:]}")
            try: result = json.loads(out.decode())
            except json.JSONDecodeError: result = {"image": out}
        if isinstance(result, ScreenFrame): return result
        if isinstance(result, dict):
            image = result.get("image")
            if result.get("image_b64"):
                image = base64.b64decode(result["image_b64"])
            return ScreenFrame(image=image, width=result.get("width"), height=result.get("height"), metadata=dict(result.get("metadata", {})))
        return ScreenFrame(image=result)

    async def execute(self, arguments: dict[str, Any] | None = None):
        return await self.capture()
