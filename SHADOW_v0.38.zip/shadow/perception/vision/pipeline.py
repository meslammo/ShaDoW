from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable
from .adapter import VisionObservation

@dataclass(frozen=True)
class PerceptionCycle:
    observation: VisionObservation
    action: Any = None
    verified: bool | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

class VisionPipeline:
    """Perceive -> optional action -> optional verification, with bounded provider calls."""
    def __init__(self, vision, action=None, verifier=None):
        self.vision, self.action, self.verifier = vision, action, verifier

    async def _call(self, obj, method: str, *args, **kwargs):
        fn = getattr(obj, method) if isinstance(method, str) else method
        value = fn(*args, **kwargs)
        return await value if hasattr(value, "__await__") else value

    async def perceive(self, image: Any, *, context: dict[str, Any] | None = None) -> VisionObservation:
        return await self._call(self.vision, "analyze", image, context=context or {})

    async def run(self, image: Any, *, context: dict[str, Any] | None = None,
                  action_arguments: dict[str, Any] | None = None) -> PerceptionCycle:
        observation = await self.perceive(image, context=context)
        if self.action is None or action_arguments is None:
            return PerceptionCycle(observation=observation)
        result = await self._call(self.action, "execute", action_arguments)
        verified = None
        if self.verifier is not None:
            verified = bool(await self._call(self.verifier, "verify", observation, result, context=context or {}))
        return PerceptionCycle(observation=observation, action=result, verified=verified)
