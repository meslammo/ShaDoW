from __future__ import annotations
import asyncio, base64, json, os
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

@dataclass(frozen=True)
class VisionObservation:
    summary: str
    elements: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

class VisionAdapter:
    """Provider-neutral image understanding adapter with optional isolated JSONL runner."""
    name = "vision"
    risky = False
    def __init__(self, runner: Callable[[Any], Awaitable[Any]] | None = None,
                 command: list[str] | None = None, *, cwd=None, env=None, timeout=120.0):
        self._runner, self.command, self.cwd, self.env, self.timeout = runner, command, cwd, env, timeout

    def bind(self, runner): self._runner = runner; return self

    async def _subprocess(self, image: Any):
        if not self.command: raise RuntimeError("isolated vision runner is not configured")
        if isinstance(image, bytes): payload = {"image_b64": base64.b64encode(image).decode("ascii")}
        elif isinstance(image, str): payload = {"image": image}
        else: payload = {"image": image}
        env = os.environ.copy(); env.update(self.env or {})
        proc = await asyncio.create_subprocess_exec(*self.command, stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=self.cwd, env=env)
        out, err = await asyncio.wait_for(proc.communicate((json.dumps(payload, default=str)+"\n").encode()), self.timeout)
        if proc.returncode != 0: raise RuntimeError(f"vision runner failed: {err.decode(errors='replace')[-4000:]}")
        try: return json.loads(out.decode())
        except json.JSONDecodeError: return out.decode()

    async def analyze(self, image: Any, *, context: dict[str, Any] | None = None) -> VisionObservation:
        if image is None: raise ValueError("image is required")
        result = await self._runner(image) if self._runner else await self._subprocess(image)
        if isinstance(result, VisionObservation): return result
        if isinstance(result, dict):
            return VisionObservation(summary=str(result.get("summary", result.get("text", ""))),
                elements=list(result.get("elements", [])), metadata=dict(result.get("metadata", {})))
        return VisionObservation(summary=str(result), metadata={"context": context or {}})

    async def execute(self, arguments: dict[str, Any]):
        return await self.analyze(arguments.get("image"), context=arguments.get("context"))
