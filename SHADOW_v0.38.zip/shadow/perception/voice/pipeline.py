from __future__ import annotations
import asyncio
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable

@dataclass(frozen=True)
class VoiceTurn:
    transcript: str
    response: str | None = None
    interrupted: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

class VoicePipeline:
    """Provider-neutral Wake -> VAD -> STT -> brain -> TTS pipeline."""
    def __init__(self, wake=None, vad=None, stt=None, tts=None, brain=None):
        self.wake, self.vad, self.stt, self.tts, self.brain = wake, vad, stt, tts, brain

    async def _call(self, obj, method: str, *args, **kwargs):
        fn = getattr(obj, method)
        value = fn(*args, **kwargs)
        return await value if hasattr(value, "__await__") else value

    async def transcribe(self, audio: Any):
        if self.vad is not None:
            audio = await self._call(self.vad, "filter", audio)
            if audio is None:
                return ""
        if self.stt is None:
            raise RuntimeError("STT adapter is not configured")
        return await self._call(self.stt, "transcribe", audio)

    async def speak(self, text: str, cancel_event: asyncio.Event | None = None):
        if self.tts is None:
            raise RuntimeError("TTS adapter is not configured")
        if cancel_event is None:
            return await self._call(self.tts, "speak", text)
        task = asyncio.create_task(self._call(self.tts, "speak", text))
        stop = asyncio.create_task(cancel_event.wait())
        done, _ = await asyncio.wait({task, stop}, return_when=asyncio.FIRST_COMPLETED)
        if stop in done and cancel_event.is_set():
            if hasattr(self.tts, "stop"):
                await self._call(self.tts, "stop")
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            return False
        stop.cancel()
        return task.result()

    async def run_turn(self, audio: Any, *, context: dict[str, Any] | None = None,
                       cancel_event: asyncio.Event | None = None) -> VoiceTurn:
        transcript = await self.transcribe(audio)
        if not transcript.strip():
            return VoiceTurn(transcript="")
        if self.brain is None:
            return VoiceTurn(transcript=transcript)
        response = await self._call(self.brain, "respond", transcript, context=context or {})
        interrupted = False
        if response:
            spoken = await self.speak(str(response), cancel_event=cancel_event)
            interrupted = spoken is False
        return VoiceTurn(transcript=transcript, response=str(response) if response is not None else None,
                         interrupted=interrupted)
