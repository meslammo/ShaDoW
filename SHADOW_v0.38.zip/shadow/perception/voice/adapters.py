from __future__ import annotations
from typing import Any

class CallableWakeWord:
    def __init__(self, detector): self.detector = detector
    async def detect(self, audio: Any) -> bool:
        value = self.detector(audio)
        return await value if hasattr(value, "__await__") else bool(value)

class PassthroughVAD:
    async def filter(self, audio: Any) -> Any:
        return audio

class CallableSTT:
    def __init__(self, transcriber): self.transcriber = transcriber
    async def transcribe(self, audio: Any) -> str:
        value = self.transcriber(audio)
        return await value if hasattr(value, "__await__") else str(value)

class CallableTTS:
    def __init__(self, speaker, stopper=None): self.speaker, self.stopper = speaker, stopper
    async def speak(self, text: str):
        value = self.speaker(text)
        return await value if hasattr(value, "__await__") else value
    async def stop(self):
        if self.stopper is None: return None
        value = self.stopper()
        return await value if hasattr(value, "__await__") else value

class CallableBrain:
    def __init__(self, responder): self.responder = responder
    async def respond(self, transcript: str, *, context: dict[str, Any]):
        value = self.responder(transcript, context)
        return await value if hasattr(value, "__await__") else value
