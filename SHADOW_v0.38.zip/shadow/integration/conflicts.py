from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import difflib

@dataclass(frozen=True)
class Conflict:
    path: str
    source_sha256: str
    target_sha256: str

class ConflictResolver:
    """Detects file conflicts without changing either tree."""
    def __init__(self, integration_engine=None):
        from .engine import IntegrationEngine
        self.engine = integration_engine or IntegrationEngine()

    def detect(self, source_root: str | Path, target_root: str | Path, files) -> list[Conflict]:
        source = Path(source_root).resolve(); target = Path(target_root).resolve()
        conflicts=[]
        for value in files:
            rel=self.engine._safe_relative(value)
            src=(source/rel).resolve(); dst=(target/rel).resolve()
            self.engine._ensure_inside(src, source); self.engine._ensure_inside(dst, target)
            if src.is_file() and dst.is_file():
                ss=self.engine._sha256(src); ts=self.engine._sha256(dst)
                if ss != ts: conflicts.append(Conflict(rel.as_posix(), ss, ts))
        return conflicts

    def unified_diff(self, source_root: str | Path, target_root: str | Path, path: str, *, max_lines: int = 400) -> str:
        source=Path(source_root).resolve(); target=Path(target_root).resolve(); rel=self.engine._safe_relative(path)
        a=(source/rel).read_text(encoding='utf-8', errors='replace').splitlines(keepends=True)
        b=(target/rel).read_text(encoding='utf-8', errors='replace').splitlines(keepends=True)
        diff=difflib.unified_diff(b,a,fromfile=f'target/{rel}',tofile=f'source/{rel}')
        return ''.join(list(diff)[:max_lines])
