from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .checkpoint import Checkpoint, CheckpointManager
from .engine import IntegrationEngine, IntegrationPlan, IntegrationResult
from .regression import RegressionEngine, RegressionResult
from .rollback import RollbackEngine
from ..recovery.healing import SelfHealingEngine, HealingResult


@dataclass
class IntegrationTransactionResult:
    committed: bool
    rolled_back: bool
    integration: IntegrationResult | None = None
    regression: RegressionResult | None = None
    checkpoint: Checkpoint | None = None
    error: str | None = None
    events: list[str] = field(default_factory=list)
    healing: HealingResult | None = None


class IntegrationTransaction:
    """Atomic-ish integration flow: checkpoint -> integrate -> regress -> commit/rollback."""

    def __init__(self, *, integration=None, checkpoints=None, regression=None, rollback=None, healing=None):
        self.integration = integration or IntegrationEngine()
        self.checkpoints = checkpoints or CheckpointManager()
        self.regression = regression or RegressionEngine()
        self.rollback = rollback or RollbackEngine()
        self.healing = healing or SelfHealingEngine(max_attempts=1)

    def run(
        self,
        source_root: str | Path,
        target_root: str | Path,
        files: Iterable[str],
        *,
        mode: str = "fail",
        test_command: tuple[str, ...] | None = None,
        dry_run: bool = False,
        repair=None,
        healing_attempts: int | None = None,
    ) -> IntegrationTransactionResult:
        target = Path(target_root).resolve()
        if not target.is_dir():
            raise NotADirectoryError(target)

        events: list[str] = []
        checkpoint = None
        try:
            plan = self.integration.plan(source_root, target, files, mode=mode)
            events.append("planned")
            if dry_run:
                result = self.integration.apply(plan, dry_run=True)
                events.append("dry-run")
                return IntegrationTransactionResult(True, False, result, None, None, events=events)

            checkpoint = self.checkpoints.create(target)
            events.append("checkpoint-created")
            result = self.integration.apply(plan)
            events.append("integrated")
            regression = self.regression.run(target, command=test_command)
            events.append("regression-passed" if regression.passed else "regression-failed")
            healing_result = None
            if not regression.passed and repair is not None:
                engine = self.healing if healing_attempts is None else SelfHealingEngine(max_attempts=healing_attempts)
                healing_result = engine.run(
                    lambda: self.regression.run(target, command=test_command),
                    repair=repair,
                    success=lambda value: value.passed,
                )
                regression = self.regression.run(target, command=test_command) if healing_result.success else regression
                events.append("healing-passed" if healing_result.success else "healing-failed")
            if regression.passed:
                events.append("committed")
                return IntegrationTransactionResult(True, False, result, regression, checkpoint, events=events, healing=healing_result)

            self.rollback.rollback(checkpoint, target)
            events.append("rolled-back")
            return IntegrationTransactionResult(False, True, result, regression, checkpoint,
                                                error="regression failed; integration rolled back",
                                                events=events, healing=healing_result)
        except Exception as exc:
            if checkpoint is not None and target.is_dir():
                try:
                    self.rollback.rollback(checkpoint, target)
                    events.append("rolled-back-after-error")
                except Exception as rollback_exc:
                    events.append(f"rollback-failed: {rollback_exc}")
                    return IntegrationTransactionResult(False, False, None, None, checkpoint,
                                                        error=f"{exc}; rollback failed: {rollback_exc}",
                                                        events=events)
            return IntegrationTransactionResult(False, checkpoint is not None and "rolled-back-after-error" in events,
                                                None, None, checkpoint, error=str(exc), events=events)
