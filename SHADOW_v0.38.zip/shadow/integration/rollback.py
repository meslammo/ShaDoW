from __future__ import annotations

from pathlib import Path
import shutil
from .checkpoint import Checkpoint

class RollbackEngine:
    """Restores a checkpoint and removes files created after it."""
    def rollback(self, checkpoint: Checkpoint, target_root: str | Path) -> None:
        target = Path(target_root).resolve()
        if not target.is_dir():
            raise NotADirectoryError(target)
        # Restore files captured by the checkpoint.
        base = Path(checkpoint.path).resolve()
        for rel_text in checkpoint.files:
            rel = Path(rel_text)
            src = (base / rel).resolve()
            dst = (target / rel).resolve()
            try: dst.relative_to(target)
            except ValueError as exc: raise ValueError(f"path escapes target: {dst}") from exc
            if not src.is_file(): raise FileNotFoundError(src)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        # Checkpoint metadata tells us the pre-existing file set. Remove files
        # under target that were not present at checkpoint creation.
        original = {Path(x).as_posix() for x in checkpoint.files}
        for p in target.rglob("*"):
            if not p.is_file(): continue
            rel = p.relative_to(target).as_posix()
            if rel == "checkpoint.json": continue
            # Only remove files if the checkpoint was explicitly created with
            # a complete file inventory marker.
            if getattr(checkpoint, "complete", False) and rel not in original:
                p.unlink()
