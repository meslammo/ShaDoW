from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import hashlib
import shutil
from typing import Iterable


class IntegrationConflict(FileExistsError):
    """Raised when integration would overwrite an existing file."""


@dataclass(frozen=True)
class IntegrationPlan:
    source_root: str
    target_root: str
    files: tuple[str, ...]
    mode: str = "fail"


@dataclass
class IntegrationResult:
    copied: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    overwritten: list[str] = field(default_factory=list)
    manifest: list[dict[str, str]] = field(default_factory=list)


class IntegrationEngine:
    """Conservative file-level integration into a Shadow workspace.

    The engine never executes candidate code and never mutates the source tree.
    Conflict modes: ``fail`` (default), ``skip``, or ``overwrite``.
    """

    def plan(self, source_root: str | Path, target_root: str | Path,
             files: Iterable[str], *, mode: str = "fail") -> IntegrationPlan:
        source = Path(source_root).resolve()
        target = Path(target_root).resolve()
        if not source.is_dir():
            raise NotADirectoryError(source)
        if mode not in {"fail", "skip", "overwrite"}:
            raise ValueError("mode must be fail, skip, or overwrite")
        normalized = tuple(self._safe_relative(f) for f in files)
        for rel in normalized:
            if not (source / rel).is_file():
                raise FileNotFoundError(source / rel)
        return IntegrationPlan(str(source), str(target), normalized, mode)

    def apply(self, plan: IntegrationPlan, *, dry_run: bool = False) -> IntegrationResult:
        source = Path(plan.source_root).resolve()
        target = Path(plan.target_root).resolve()
        result = IntegrationResult()
        for rel_text in plan.files:
            rel = self._safe_relative(rel_text)
            src = (source / rel).resolve()
            dst = (target / rel).resolve()
            self._ensure_inside(src, source)
            self._ensure_inside(dst, target)
            if not src.is_file():
                raise FileNotFoundError(src)
            exists = dst.exists()
            if exists and plan.mode == "fail":
                raise IntegrationConflict(dst)
            if exists and plan.mode == "skip":
                result.skipped.append(rel.as_posix())
                continue
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            digest = self._sha256(src)
            entry = {"path": rel.as_posix(), "sha256": digest}
            result.manifest.append(entry)
            if exists:
                result.overwritten.append(rel.as_posix())
            else:
                result.copied.append(rel.as_posix())
        return result

    @staticmethod
    def _safe_relative(value: str) -> Path:
        rel = Path(value)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError(f"unsafe integration path: {value}")
        return rel

    @staticmethod
    def _ensure_inside(path: Path, root: Path) -> None:
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"path escapes integration root: {path}") from exc

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
