from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess
import sys

@dataclass(frozen=True)
class RegressionResult:
    passed: bool
    returncode: int
    output: str
    command: tuple[str, ...]

class RegressionEngine:
    """Runs an isolated test command against a target workspace."""
    def __init__(self, *, timeout: int = 120, max_output: int = 20000):
        self.timeout = timeout
        self.max_output = max_output

    def run(self, target_root: str | Path, *, command: tuple[str, ...] | None = None) -> RegressionResult:
        root = Path(target_root).resolve()
        if not root.is_dir():
            raise NotADirectoryError(root)
        cmd = command or (sys.executable, "-m", "pytest", "-q")
        if not cmd:
            raise ValueError("command cannot be empty")
        try:
            p = subprocess.run(cmd, cwd=root, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, timeout=self.timeout, shell=False,
                               check=False)
            output = p.stdout[-self.max_output:]
            return RegressionResult(p.returncode == 0, p.returncode, output, tuple(cmd))
        except subprocess.TimeoutExpired as exc:
            text = (exc.stdout or "")
            if isinstance(text, bytes): text = text.decode(errors="replace")
            text = text[-self.max_output:]
            return RegressionResult(False, -1, text + "\n[timeout]", tuple(cmd))
