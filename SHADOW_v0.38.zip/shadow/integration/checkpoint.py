from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json, shutil, tempfile
from datetime import datetime, timezone

@dataclass(frozen=True)
class Checkpoint:
    path: str
    created_at: str
    files: tuple[str, ...]
    complete: bool = False

class CheckpointManager:
    """Creates/restores a private snapshot of selected target files."""
    def create(self, target_root: str | Path, files=None, *, directory: str | Path | None = None, complete: bool = False) -> Checkpoint:
        target=Path(target_root).resolve()
        if not target.is_dir(): raise NotADirectoryError(target)
        base=Path(directory) if directory else Path(tempfile.mkdtemp(prefix='shadow-checkpoint-'))
        base=base.resolve(); base.mkdir(parents=True, exist_ok=True)
        if files is None:
            files = [p.relative_to(target).as_posix() for p in target.rglob("*") if p.is_file()]
            complete = True
        saved=[]
        for value in files:
            rel=Path(value)
            if rel.is_absolute() or '..' in rel.parts: raise ValueError(f'unsafe checkpoint path: {value}')
            src=(target/rel).resolve()
            try: src.relative_to(target)
            except ValueError as exc: raise ValueError(f'path escapes target: {src}') from exc
            if src.is_file():
                dst=base/rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,dst); saved.append(rel.as_posix())
        meta={'created_at':datetime.now(timezone.utc).isoformat(),'files':saved}
        (base/'checkpoint.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
        return Checkpoint(str(base), meta['created_at'], tuple(saved), complete=complete)

    def restore(self, checkpoint: Checkpoint, target_root: str | Path) -> None:
        target=Path(target_root).resolve(); base=Path(checkpoint.path).resolve()
        for value in checkpoint.files:
            rel=Path(value); src=(base/rel).resolve(); dst=(target/rel).resolve()
            try: dst.relative_to(target)
            except ValueError as exc: raise ValueError(f'path escapes target: {dst}') from exc
            if not src.is_file(): raise FileNotFoundError(src)
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,dst)
