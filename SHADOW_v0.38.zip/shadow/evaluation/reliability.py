from __future__ import annotations

import asyncio
import inspect
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Iterable


@dataclass(frozen=True)
class ReliabilityScenario:
    name: str
    goal: str
    tools: dict[str, object]
    expected_success: bool = True
    context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ReliabilityResult:
    name: str
    passed: bool
    expected_success: bool
    actual_success: bool
    error: str | None = None
    events: tuple[str, ...] = ()
    duration_ms: float = 0.0
    invariant_errors: tuple[str, ...] = ()


@dataclass(frozen=True)
class ReliabilityReport:
    total: int
    passed: int
    failed: int
    success_rate: float
    results: tuple[ReliabilityResult, ...]


class ReliabilityEvaluator:
    """Runs bounded, deterministic scenarios against the public Shadow runtime/agent API.

    This is an evaluation harness, not a second execution path. Scenarios invoke the
    supplied runtime and can enforce invariants without bypassing its security gates.
    """

    def __init__(self, runner: Callable[..., Awaitable[Any]] | Callable[..., Any], *, timeout_s: float = 10.0):
        if timeout_s <= 0:
            raise ValueError("timeout_s must be > 0")
        self.runner = runner
        self.timeout_s = timeout_s

    async def _call(self, scenario: ReliabilityScenario) -> Any:
        value = self.runner(scenario.goal, scenario.tools, context=scenario.context)
        if inspect.isawaitable(value):
            return await asyncio.wait_for(value, timeout=self.timeout_s)
        return value

    @staticmethod
    def _invariants(result: Any, expected_success: bool) -> list[str]:
        errors: list[str] = []
        if not hasattr(result, "success"):
            return ["runner result has no success field"]
        if bool(result.success) != expected_success:
            errors.append(f"expected success={expected_success}, got {result.success}")
        events = tuple(getattr(result, "events", ()) or ())
        if result.success and "completed" not in events:
            errors.append("successful run missing completed event")
        if not result.success and not ({"failed", "step-failed"} & set(events)):
            errors.append("failed run missing failure event")
        if len(events) != len(set(events)) and "completed" in events:
            errors.append("completed event appears more than once")
        return errors

    async def run_one(self, scenario: ReliabilityScenario) -> ReliabilityResult:
        loop = asyncio.get_running_loop()
        start = loop.time()
        try:
            result = await self._call(scenario)
            errors = self._invariants(result, scenario.expected_success)
            return ReliabilityResult(
                scenario.name, not errors, scenario.expected_success, bool(result.success),
                error=getattr(result, "error", None), events=tuple(getattr(result, "events", ()) or ()),
                duration_ms=(loop.time() - start) * 1000, invariant_errors=tuple(errors),
            )
        except Exception as exc:
            return ReliabilityResult(
                scenario.name, False, scenario.expected_success, False, error=str(exc),
                duration_ms=(loop.time() - start) * 1000, invariant_errors=(f"runner exception: {exc}",),
            )

    async def run(self, scenarios: Iterable[ReliabilityScenario]) -> ReliabilityReport:
        results = tuple([await self.run_one(scenario) for scenario in scenarios])
        passed = sum(item.passed for item in results)
        total = len(results)
        return ReliabilityReport(total, passed, total - passed, passed / total if total else 1.0, results)
