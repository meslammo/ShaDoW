from __future__ import annotations
from pathlib import Path
from typing import Any

class FilesystemTool:
    """Constrained filesystem tool; every path is resolved under an allowed root."""
    name = "filesystem"
    risky = True

    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, value: str) -> Path:
        if not value:
            raise ValueError("path is required")
        p = (self.root / value).resolve()
        try:
            p.relative_to(self.root)
        except ValueError as exc:
            raise PermissionError("path escapes filesystem root") from exc
        return p

    async def execute(self, arguments: dict[str, Any]) -> Any:
        op = str(arguments.get("operation", "")).strip().lower()
        path = self._path(str(arguments.get("path", "")))
        if op == "list":
            if not path.is_dir(): raise NotADirectoryError(str(path))
            return sorted(p.name for p in path.iterdir())
        if op == "read":
            if not path.is_file(): raise FileNotFoundError(str(path))
            return path.read_text(encoding="utf-8")
        if op == "write":
            content = arguments.get("content")
            if not isinstance(content, str): raise ValueError("content must be a string")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return {"path": str(path.relative_to(self.root)), "bytes": len(content.encode("utf-8"))}
        if op == "delete":
            if path.is_dir(): raise IsADirectoryError(str(path))
            path.unlink()
            return {"deleted": str(path.relative_to(self.root))}
        raise ValueError("unsupported filesystem operation")
