from __future__ import annotations
import asyncio, json, os
from typing import Any, Awaitable, Callable

class MCPClientAdapter:
    """MCP client boundary supporting injected transports or a real stdio JSON-RPC server."""
    def __init__(self, caller: Callable[[str, dict[str, Any]], Awaitable[Any]] | None = None,
                 command: list[str] | None = None, *, cwd: str | None = None,
                 env: dict[str, str] | None = None, timeout: float = 30.0):
        self._caller = caller
        self.command = command
        self.cwd = cwd
        self.env = env
        self.timeout = timeout
        self._proc: asyncio.subprocess.Process | None = None
        self._next_id = 0
        self._lock = asyncio.Lock()

    def bind(self, caller):
        self._caller = caller
        return self

    async def _ensure_process(self):
        if self._proc is not None and self._proc.returncode is None:
            return
        if not self.command:
            raise RuntimeError("MCP transport is not configured")
        env = os.environ.copy()
        if self.env: env.update(self.env)
        self._proc = await asyncio.create_subprocess_exec(
            *self.command, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, cwd=self.cwd, env=env)
        await self._request("initialize", {
            "protocolVersion": "2025-06-18",
            "capabilities": {},
            "clientInfo": {"name": "shadow", "version": "0.27"},
        }, initialize=False)
        await self._notify("notifications/initialized", {})

    async def _notify(self, method: str, params: dict[str, Any]):
        if not self._proc or not self._proc.stdin: raise RuntimeError("MCP process unavailable")
        self._proc.stdin.write((json.dumps({"jsonrpc":"2.0","method":method,"params":params})+"\n").encode())
        await self._proc.stdin.drain()

    async def _request(self, method: str, params: dict[str, Any], *, initialize=True):
        if initialize and self._proc is None: await self._ensure_process()
        if not self._proc or not self._proc.stdin or not self._proc.stdout:
            raise RuntimeError("MCP process unavailable")
        self._next_id += 1; request_id = self._next_id
        self._proc.stdin.write((json.dumps({"jsonrpc":"2.0","id":request_id,"method":method,"params":params})+"\n").encode())
        await self._proc.stdin.drain()
        while True:
            line = await asyncio.wait_for(self._proc.stdout.readline(), timeout=self.timeout)
            if not line: raise RuntimeError("MCP server closed stdout")
            msg = json.loads(line)
            if msg.get("id") != request_id: continue
            if "error" in msg: raise RuntimeError(str(msg["error"]))
            return msg.get("result")

    async def call(self, tool_name: str, arguments: dict[str, Any]):
        if self._caller is not None:
            return await self._caller(tool_name, arguments)
        await self._ensure_process()
        return await self._request("tools/call", {"name": tool_name, "arguments": arguments})

    async def list_tools(self):
        await self._ensure_process()
        return await self._request("tools/list", {})

    async def execute(self, arguments: dict[str, Any]):
        name = str(arguments.get("tool_name", "")).strip()
        if not name: raise ValueError("MCP tool_name is required")
        return await self.call(name, dict(arguments.get("arguments", {})))

    async def close(self):
        if self._proc is not None and self._proc.returncode is None:
            self._proc.terminate()
            try: await asyncio.wait_for(self._proc.wait(), 2)
            except asyncio.TimeoutError: self._proc.kill(); await self._proc.wait()
        self._proc = None
