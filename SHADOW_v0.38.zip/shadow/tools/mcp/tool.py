from __future__ import annotations
from typing import Any
from .client import MCPClientAdapter

class MCPTool:
    """Expose one remote MCP tool through Shadow's normal secure executor boundary."""
    risky = True

    def __init__(self, client: MCPClientAdapter, name: str, *, description: str = ""):
        self.client, self.name, self.description = client, name, description

    async def execute(self, arguments: dict[str, Any]) -> Any:
        return await self.client.call(self.name, arguments)
