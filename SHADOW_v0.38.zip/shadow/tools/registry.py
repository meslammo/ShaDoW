from __future__ import annotations
from typing import Iterable

class ToolCatalog:
    """Runtime tool catalog with explicit registration and deterministic lookup."""
    def __init__(self, tools: Iterable[object] = ()):
        self._tools: dict[str, object] = {}
        for tool in tools:
            self.register(tool)

    def register(self, tool: object) -> object:
        name = str(getattr(tool, "name", "")).strip()
        if not name:
            raise ValueError("tool name is required")
        if name in self._tools:
            raise ValueError(f"duplicate tool: {name}")
        if not callable(getattr(tool, "execute", None)):
            raise TypeError(f"tool {name!r} must expose execute()")
        self._tools[name] = tool
        return tool

    def get(self, name: str) -> object:
        try: return self._tools[name]
        except KeyError as exc: raise KeyError(f"unknown tool: {name}") from exc

    def as_dict(self) -> dict[str, object]:
        return dict(self._tools)

    def manifest(self) -> list[dict[str, object]]:
        return [{"name": n, "risky": bool(getattr(t, "risky", False)), "description": str(getattr(t, "description", ""))}
                for n, t in self._tools.items()]
