from __future__ import annotations
import asyncio, json, os
from typing import Any, Awaitable, Callable

class ComputerUseAdapter:
    """Computer-use tool with a real isolated JSONL subprocess runner or injected runner."""
    name="computer"; risky=True
    def __init__(self, runner: Callable[[str], Awaitable[Any]] | None=None,
                 command: list[str] | None=None, *, cwd=None, env=None, timeout=120.0):
        self._runner, self.command, self.cwd, self.env, self.timeout = runner, command, cwd, env, timeout
    def bind(self, runner): self._runner=runner; return self
    async def _subprocess(self, goal: str):
        if not self.command: raise RuntimeError("computer-use runner is not configured")
        env=os.environ.copy(); env.update(self.env or {})
        proc=await asyncio.create_subprocess_exec(*self.command, stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=self.cwd, env=env)
        out, err=await asyncio.wait_for(proc.communicate((json.dumps({"goal":goal})+"\n").encode()), self.timeout)
        if proc.returncode != 0: raise RuntimeError(f"computer runner failed: {err.decode(errors='replace')[-4000:]}")
        try: return json.loads(out.decode())
        except json.JSONDecodeError: return out.decode()
    async def execute(self, arguments: dict[str, Any]):
        goal=str(arguments.get("goal", "")).strip()
        if not goal: raise ValueError("computer goal is required")
        return await self._runner(goal) if self._runner else await self._subprocess(goal)
    async def run(self, goal: str): return await self.execute({"goal":goal})
