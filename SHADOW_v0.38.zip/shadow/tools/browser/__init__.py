from .adapter import BrowserAdapter

__all__ = ["BrowserAdapter"]
