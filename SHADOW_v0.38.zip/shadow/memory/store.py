from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import re
from typing import Any
import uuid


@dataclass
class Memory:
    kind: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class MemoryStore:
    """Small local-first memory store with typed memories and deterministic recall.

    It intentionally has no external vector database dependency. A stronger backend can
    implement the same async methods and be injected later.
    """
    KINDS = {"episodic", "semantic", "procedural", "failure"}

    def __init__(self):
        self._items: list[Memory] = []

    async def add(self, memory: Memory) -> Memory:
        if memory.kind not in self.KINDS:
            raise ValueError(f"unsupported memory kind: {memory.kind}")
        self._items.append(memory)
        return memory

    async def recall(self, query: str, limit: int = 5, *, kind: str | None = None) -> list[Memory]:
        if limit < 1:
            return []
        tokens = set(re.findall(r"[\w]+", query.lower()))
        if not tokens:
            return []
        candidates = [m for m in self._items if kind is None or m.kind == kind]
        ranked: list[tuple[float, int, Memory]] = []
        for position, memory in enumerate(candidates):
            haystack = set(re.findall(r"[\w]+", memory.content.lower()))
            overlap = len(tokens & haystack)
            if overlap == 0:
                continue
            # Recency is only a small tie-breaker; relevance remains dominant.
            age_bonus = position / max(len(candidates), 1) * 0.01
            ranked.append((overlap + age_bonus, position, memory))
        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return [item[2] for item in ranked[:limit]]

    async def recall_context(self, query: str, limit: int = 5) -> str:
        memories = await self.recall(query, limit)
        return "\n\n".join(m.content for m in memories)

    async def add_result(self, *, goal: str, step: str, result: Any, verdict: Any):
        ok = bool(getattr(verdict, "accept", False))
        kind = "procedural" if ok else "failure"
        return await self.add(Memory(
            kind,
            f"Goal: {goal}\nStep: {step}\nResult: {result}\nAccepted: {ok}",
            {"goal": goal, "step": step, "accepted": ok},
        ))

    async def add_run(self, *, goal: str, success: bool, steps: int, decision: Any = None) -> Memory:
        return await self.add(Memory(
            "episodic",
            f"Goal: {goal}\nRun success: {success}\nSteps: {steps}\nDecision: {decision}",
            {"goal": goal, "success": success, "steps": steps, "decision": str(decision)},
        ))

    async def add_fact(self, content: str, **metadata: Any) -> Memory:
        return await self.add(Memory("semantic", content, metadata))

    def items(self, *, kind: str | None = None) -> list[Memory]:
        return [m for m in self._items if kind is None or m.kind == kind]

    def __len__(self) -> int:
        return len(self._items)
