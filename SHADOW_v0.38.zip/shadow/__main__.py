from shadow.production.service import main
raise SystemExit(main())
