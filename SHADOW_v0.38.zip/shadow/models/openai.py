from __future__ import annotations
import inspect
from typing import Any, Sequence

from .contracts import ModelResponse

class OpenAIProvider:
    """Provider-neutral OpenAI Responses API adapter.

    The SDK client is injectable for tests. The provider never stores the API key;
    the official SDK reads OPENAI_API_KEY from the environment by default.
    """
    name = "openai"

    def __init__(self, model: str = "gpt-5.6-luna", *, client: Any = None):
        self.model = model
        self._client = client

    def _client_or_create(self):
        if self._client is not None:
            return self._client
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise RuntimeError("OpenAI provider requires the 'openai' package") from exc
        self._client = AsyncOpenAI()
        return self._client

    @staticmethod
    def _input(system: str | None, messages: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        if system:
            items.append({"role": "system", "content": system})
        items.extend(dict(m) for m in messages)
        return items

    async def complete(self, *, model: str, system: str | None,
                       messages: Sequence[dict[str, Any]], max_tokens: int = 4096,
                       temperature: float = 0.0) -> ModelResponse:
        client = self._client_or_create()
        kwargs = {"model": model or self.model, "input": self._input(system, messages),
                  "max_output_tokens": max_tokens}
        # Responses models may reject temperature; keep the abstraction stable without
        # forcing unsupported parameters onto the API.
        if temperature != 0.0:
            kwargs["temperature"] = temperature
        response = client.responses.create(**kwargs)
        if inspect.isawaitable(response):
            response = await response
        text = getattr(response, "output_text", None)
        if text is None:
            text = ""
            for item in getattr(response, "output", []) or []:
                for content in getattr(item, "content", []) or []:
                    value = getattr(content, "text", None)
                    if value:
                        text += value
        usage_obj = getattr(response, "usage", None)
        usage = {}
        if usage_obj is not None:
            for key in ("input_tokens", "output_tokens", "total_tokens"):
                value = getattr(usage_obj, key, None)
                if value is not None:
                    usage[key] = value
        return ModelResponse(text=text, model=getattr(response, "model", model or self.model),
                             provider=self.name, raw=response, usage=usage)
