from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol, Sequence

@dataclass(frozen=True)
class ModelMessage:
    role: str
    content: Any

@dataclass(frozen=True)
class ModelResponse:
    text: str
    model: str
    provider: str
    raw: Any = None
    usage: dict[str, Any] = field(default_factory=dict)

class ModelProvider(Protocol):
    name: str
    model: str
    async def complete(
        self,
        *,
        model: str,
        system: str | None,
        messages: Sequence[dict[str, Any]],
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> ModelResponse: ...
