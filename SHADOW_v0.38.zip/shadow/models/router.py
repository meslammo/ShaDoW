from __future__ import annotations
from typing import Any

class ModelRouter:
    """Selects a provider by task, with an explicit default and fail-closed fallback."""
    def __init__(self, providers: dict[str, Any], *, default: str):
        if default not in providers:
            raise ValueError("default provider must be registered")
        if not providers:
            raise ValueError("at least one provider is required")
        self.providers = dict(providers)
        self.default = default

    def select(self, task: str | None = None, *, preferred: str | None = None):
        name = preferred or self.default
        if name not in self.providers:
            raise KeyError(f"unknown model provider: {name}")
        return self.providers[name]

    async def complete(self, *, task: str | None = None, preferred: str | None = None, **kwargs):
        provider = self.select(task, preferred=preferred)
        # `task` belongs to the router; provider contracts stay provider-neutral.
        return await provider.complete(**kwargs)
