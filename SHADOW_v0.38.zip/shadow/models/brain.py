from __future__ import annotations
from typing import Any, Sequence

from .contracts import ModelResponse
from .router import ModelRouter


class ShadowBrain:
    """The model-facing brain boundary used by reasoning components.

    The brain owns provider/model routing but does not execute tools. Planner and
    Critic can share this boundary, keeping model selection out of the core logic.
    """

    def __init__(self, router: ModelRouter, *, task_providers: dict[str, str] | None = None):
        self.router = router
        self.task_providers = dict(task_providers or {})

    def provider_for(self, task: str | None = None) -> Any:
        preferred = self.task_providers.get(task or "")
        return self.router.select(task, preferred=preferred)

    async def complete(
        self,
        *,
        model: str,
        system: str | None,
        messages: Sequence[dict[str, Any]],
        max_tokens: int = 4096,
        temperature: float = 0.0,
        task: str | None = None,
    ) -> ModelResponse:
        preferred = self.task_providers.get(task or "")
        return await self.router.complete(
            task=task,
            preferred=preferred,
            model=model,
            system=system,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
