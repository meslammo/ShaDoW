from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

class PolicyDenied(PermissionError):
    pass

@dataclass(frozen=True)
class PermissionRule:
    tool_name: str
    allow: bool = False
    risky: bool = True
    required_context: tuple[str, ...] = ()

@dataclass
class SecurityPolicy:
    """Fail-closed tool permission policy. Rules are explicit and auditable."""
    rules: dict[str, PermissionRule] = field(default_factory=dict)

    def add(self, rule: PermissionRule) -> None:
        if not rule.tool_name.strip():
            raise ValueError("tool_name is required")
        self.rules[rule.tool_name] = rule

    def check(self, tool_name: str, arguments: dict[str, Any], context: dict[str, Any] | None = None, *, risky: bool = False) -> None:
        rule = self.rules.get(tool_name)
        if rule is None or not rule.allow:
            raise PolicyDenied(f"policy denied: {tool_name}")
        if risky and not rule.risky:
            raise PolicyDenied(f"policy denies risky execution: {tool_name}")
        ctx = context or {}
        missing = [key for key in rule.required_context if not ctx.get(key)]
        if missing:
            raise PolicyDenied(f"missing policy context: {', '.join(missing)}")

    def allows(self, tool_name: str) -> bool:
        return bool(self.rules.get(tool_name) and self.rules[tool_name].allow)
