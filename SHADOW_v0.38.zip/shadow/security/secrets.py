from __future__ import annotations
import os

class SecretStore:
    """Minimal secret boundary backed by environment variables; never logs values."""
    def __init__(self, prefix: str = "SHADOW_"):
        self.prefix = prefix

    def get(self, name: str) -> str:
        if not name or name.startswith("_"):
            raise ValueError("invalid secret name")
        value = os.environ.get(self.prefix + name)
        if not value:
            raise KeyError(name)
        return value

    def has(self, name: str) -> bool:
        return bool(os.environ.get(self.prefix + name))
