from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(frozen=True)
class SecurityFinding:
    severity: str
    rule: str
    path: str
    line: int | None = None
    message: str = ""


@dataclass
class SecurityReport:
    findings: list[SecurityFinding] = field(default_factory=list)

    @property
    def safe(self) -> bool:
        return not any(f.severity in {"high", "critical"} for f in self.findings)

    @property
    def high_risk(self) -> bool:
        return any(f.severity in {"high", "critical"} for f in self.findings)


class SecurityScanner:
    """Lightweight static gate; never claims to replace a full SAST tool."""

    RULES = (
        ("critical", "hardcoded-secret", re.compile(r"(?i)(api[_-]?key|secret|password|token)\s*=\s*['\"][^'\"]{8,}['\"]")),
        ("high", "shell-execution", re.compile(r"(?m)\b(os\.system|subprocess\.(run|Popen|call)|eval\(|exec\()")),
        ("high", "dynamic-import", re.compile(r"(?m)\b__import__\s*\(")),
        ("medium", "network-access", re.compile(r"(?m)\b(requests\.|httpx\.|urllib\.|socket\.)")),
    )

    def scan_text(self, text: str, path: str = "<memory>") -> SecurityReport:
        findings: list[SecurityFinding] = []
        for severity, rule, pattern in self.RULES:
            for match in pattern.finditer(text):
                line = text.count("\n", 0, match.start()) + 1
                findings.append(SecurityFinding(severity, rule, path, line, f"matched {rule}"))
        return SecurityReport(findings)

    def scan_path(self, root: str | Path) -> SecurityReport:
        root = Path(root)
        report = SecurityReport()
        if root.is_file():
            return self.scan_text(root.read_text(encoding="utf-8", errors="ignore"), str(root))
        for path in root.rglob("*.py"):
            if any(part in {".git", ".venv", "venv", "node_modules", "__pycache__"} for part in path.parts):
                continue
            report.findings.extend(self.scan_text(path.read_text(encoding="utf-8", errors="ignore"), str(path)).findings)
        return report
