from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

@dataclass(frozen=True)
class ApprovalRequest:
    tool_name: str
    arguments: dict[str, Any]
    context: dict[str, Any] | None = None

class ApprovalGateway:
    """Explicit approval boundary for risky actions.

    The callback may be sync or async. No callback means risky actions are denied.
    """
    def __init__(self, callback: Callable[[ApprovalRequest], bool | Awaitable[bool]] | None = None):
        self.callback = callback
        self.requests: list[ApprovalRequest] = []

    async def request(self, tool_name: str, arguments: dict[str, Any], context=None) -> bool:
        req = ApprovalRequest(tool_name, dict(arguments), context)
        self.requests.append(req)
        if self.callback is None:
            return False
        result = self.callback(req)
        if isinstance(result, Awaitable):
            result = await result
        return bool(result)
