from __future__ import annotations
import re
from typing import Any

_SECRET_KEY = re.compile(r"(?i)(token|secret|password|passwd|api[_-]?key|authorization|cookie|credential)")
_BEARER = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+")

class SecretRedactor:
    """Redacts secret-like fields before data reaches logs/audit output."""
    def __init__(self, replacement: str = "[REDACTED]"):
        self.replacement = replacement

    def redact(self, value: Any, *, key: str = "") -> Any:
        if _SECRET_KEY.search(key):
            return self.replacement
        if isinstance(value, dict):
            return {str(k): self.redact(v, key=str(k)) for k, v in value.items()}
        if isinstance(value, list):
            return [self.redact(v, key=key) for v in value]
        if isinstance(value, tuple):
            return tuple(self.redact(v, key=key) for v in value)
        if isinstance(value, str):
            return _BEARER.sub("Bearer " + self.replacement, value)
        return value
