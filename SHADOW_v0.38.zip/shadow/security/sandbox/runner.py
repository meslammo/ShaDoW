from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from typing import Sequence


@dataclass(frozen=True)
class SandboxResult:
    returncode: int | None
    stdout: str
    stderr: str
    timed_out: bool
    duration_ms: int
    workdir: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out


class SandboxRunner:
    """Run a candidate command in a disposable, constrained process workspace.

    This is a process/workspace sandbox, not a kernel/container security boundary.
    Production deployments should place it behind a real container/VM sandbox.
    """

    def __init__(self, *, timeout_seconds: float = 30.0, max_output_bytes: int = 256_000, allowed_executables: set[str] | None = None):
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if max_output_bytes <= 0:
            raise ValueError("max_output_bytes must be positive")
        self.timeout_seconds = timeout_seconds
        self.max_output_bytes = max_output_bytes
        self.allowed_executables = set(allowed_executables or ())

    def run(self, command: Sequence[str], *, source_dir: str | Path | None = None,
            env: dict[str, str] | None = None) -> SandboxResult:
        if isinstance(command, (str, bytes)) or not command or any(not isinstance(x, str) or not x for x in command):
            raise ValueError("command must be a non-empty sequence of strings")

        executable = Path(command[0]).name
        if self.allowed_executables and executable not in self.allowed_executables:
            raise PermissionError(f"sandbox executable not allowed: {executable}")

        source = Path(source_dir).resolve() if source_dir else None
        if source is not None and not source.is_dir():
            raise ValueError("source_dir must be a directory")

        started = time.monotonic()
        timed_out = False
        with tempfile.TemporaryDirectory(prefix="shadow-sandbox-") as temp:
            workdir = Path(temp)
            if source:
                # Copy source into disposable workspace; never execute in the original tree.
                for item in source.iterdir():
                    destination = workdir / item.name
                    if item.is_dir():
                        shutil.copytree(item, destination, ignore=shutil.ignore_patterns(
                            ".git", ".venv", "venv", "node_modules", "__pycache__"))
                    else:
                        shutil.copy2(item, destination)

            base_env = {
                "PATH": os.environ.get("PATH", ""),
                "HOME": str(workdir),
                "TMPDIR": str(workdir),
                "TEMP": str(workdir),
                "TMP": str(workdir),
                "PYTHONUNBUFFERED": "1",
            }
            if env:
                # Explicit values are opt-in; secret-looking variables are rejected.
                for key, value in env.items():
                    key = str(key)
                    if any(word in key.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")):
                        raise PermissionError(f"secret environment variable not allowed: {key}")
                    base_env[key] = str(value)

            try:
                proc = subprocess.run(
                    list(command), cwd=workdir, env=base_env,
                    stdin=subprocess.DEVNULL, capture_output=True,
                    timeout=self.timeout_seconds, check=False,
                    shell=False,
                )
                returncode = proc.returncode
                stdout = proc.stdout[: self.max_output_bytes].decode("utf-8", "replace")
                stderr = proc.stderr[: self.max_output_bytes].decode("utf-8", "replace")
            except subprocess.TimeoutExpired as exc:
                timed_out = True
                returncode = None
                stdout = (exc.stdout or b"")[: self.max_output_bytes]
                stderr = (exc.stderr or b"")[: self.max_output_bytes]
                if isinstance(stdout, bytes):
                    stdout = stdout.decode("utf-8", "replace")
                if isinstance(stderr, bytes):
                    stderr = stderr.decode("utf-8", "replace")
                stderr = (stderr + "\nshadow sandbox: timeout").strip()

            duration_ms = int((time.monotonic() - started) * 1000)
            return SandboxResult(returncode, stdout, stderr, timed_out, duration_ms, str(workdir))
