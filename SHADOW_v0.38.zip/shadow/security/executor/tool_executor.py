from __future__ import annotations
from typing import Any
from shadow.security.policy import SecurityPolicy
from shadow.security.redaction import SecretRedactor

class ActionDenied(PermissionError):
    pass

class SecureToolExecutor:
    """Single execution gateway: policy -> approval -> execute -> redacted audit."""
    def __init__(self, approval=None, audit=None, policy: SecurityPolicy | None = None, redactor: SecretRedactor | None = None):
        self.approval, self.audit, self.policy = approval, audit, policy
        self.redactor = redactor or SecretRedactor()

    async def execute(self, tool, arguments: dict[str, Any], *, risky: bool = False, context=None):
        name = getattr(tool, "name", str(tool))
        safe_args = self.redactor.redact(arguments)
        if self.audit is not None:
            await self.audit.record_action("action_requested", tool=name, arguments=safe_args, risky=risky)
        if self.policy is not None:
            try:
                self.policy.check(name, arguments, context, risky=risky)
            except PermissionError as exc:
                if self.audit is not None:
                    await self.audit.record_action("action_denied", tool=name, reason="policy_denied")
                raise ActionDenied(str(exc)) from exc
        if risky:
            if self.approval is None:
                if self.audit is not None:
                    await self.audit.record_action("action_denied", tool=name, reason="approval_required")
                raise ActionDenied(f"approval required: {name}")
            allowed = await self.approval.request(name, arguments, context=context)
            if not allowed:
                if self.audit is not None:
                    await self.audit.record_action("action_denied", tool=name, reason="approval_rejected")
                raise ActionDenied(name)
            if self.audit is not None:
                await self.audit.record_action("action_approved", tool=name)
        if not hasattr(tool, "execute"):
            raise TypeError(f"tool {tool!r} does not implement execute(arguments)")
        try:
            result = await tool.execute(arguments)
        except Exception as exc:
            if self.audit is not None:
                await self.audit.record_action("action_failed", tool=name, error=type(exc).__name__)
            raise
        if self.audit is not None:
            await self.audit.record_action("action_executed", tool=name, arguments=safe_args, result=self.redactor.redact(result))
        return result
