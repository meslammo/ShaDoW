from __future__ import annotations
import asyncio
import json
from dataclasses import dataclass
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

class HomeAssistantError(RuntimeError):
    pass

class HomeAssistantTransport(Protocol):
    async def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any: ...

@dataclass
class HttpHomeAssistantTransport:
    """Small stdlib transport for Home Assistant's REST API."""
    base_url: str
    token: str
    timeout: float = 10.0

    def __post_init__(self) -> None:
        parsed = urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("base_url must be an absolute http(s) URL")
        if parsed.username or parsed.password:
            raise ValueError("credentials must not be embedded in base_url")
        self.base_url = self.base_url.rstrip("/")
        if not self.token.strip():
            raise ValueError("token is required")

    async def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
        return await asyncio.to_thread(self._request_sync, method, path, payload)

    def _request_sync(self, method: str, path: str, payload: dict[str, Any] | None) -> Any:
        if not path.startswith("/") or ".." in path.split("/"):
            raise ValueError("invalid Home Assistant path")
        body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        req = Request(self.base_url + path, data=body, method=method.upper(), headers={
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        try:
            with urlopen(req, timeout=self.timeout) as response:
                raw = response.read()
                if not raw:
                    return None
                return json.loads(raw.decode("utf-8"))
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
            raise HomeAssistantError(f"Home Assistant HTTP {exc.code}: {detail}") from exc
        except URLError as exc:
            raise HomeAssistantError(f"Home Assistant connection failed: {exc.reason}") from exc

class _HomeAssistantBase:
    description = "Home Assistant device boundary."

    def __init__(self, transport: HomeAssistantTransport):
        self.transport = transport

    @staticmethod
    def _text(arguments: dict[str, Any], key: str) -> str:
        value = arguments.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{key} is required")
        return value.strip()

    def _entity_id(self, arguments: dict[str, Any]) -> str:
        value = self._text(arguments, "entity_id")
        if "." not in value or value.startswith(".") or value.endswith("."):
            raise ValueError("invalid entity_id")
        return value

class HomeAssistantStateTool(_HomeAssistantBase):
    """Read-only Home Assistant state tool; safe to expose without approval."""
    name = "home_assistant_state"
    risky = False

    async def execute(self, arguments: dict[str, Any]) -> Any:
        if arguments.get("action") not in {None, "get_state"}:
            raise ValueError("unsupported Home Assistant state action")
        entity_id = self._entity_id(arguments)
        return await self.transport.request("GET", "/api/states/" + quote(entity_id, safe="."))

class HomeAssistantControlTool(_HomeAssistantBase):
    """Write-only Home Assistant control tool; every invocation requires approval."""
    name = "home_assistant_control"
    risky = True

    def __init__(self, transport: HomeAssistantTransport, *, allowed_services: set[tuple[str, str]] | None = None):
        super().__init__(transport)
        self.allowed_services = set(allowed_services or set())

    async def execute(self, arguments: dict[str, Any]) -> Any:
        if arguments.get("action") != "call_service":
            raise ValueError("unsupported Home Assistant control action")
        domain = self._text(arguments, "domain")
        service = self._text(arguments, "service")
        if (domain, service) not in self.allowed_services:
            raise PermissionError(f"service not allowed: {domain}.{service}")
        service_data = arguments.get("service_data", {})
        if not isinstance(service_data, dict):
            raise ValueError("service_data must be an object")
        return await self.transport.request(
            "POST", f"/api/services/{quote(domain, safe="")}/{quote(service, safe="")}", service_data
        )

class HomeAssistantTool:
    """Compatibility bundle exposing explicit read/control sub-tools."""
    def __init__(self, transport: HomeAssistantTransport, *, allowed_services: set[tuple[str, str]] | None = None):
        self.state = HomeAssistantStateTool(transport)
        self.control = HomeAssistantControlTool(transport, allowed_services=allowed_services)

    @property
    def tools(self) -> tuple[object, object]:
        return self.state, self.control
