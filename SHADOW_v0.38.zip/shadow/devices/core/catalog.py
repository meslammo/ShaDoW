from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class Device:
    device_id: str
    name: str
    provider: str
    capabilities: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class DeviceCatalog:
    """Explicit device inventory; it never executes actions itself."""
    _devices: dict[str, Device] = field(default_factory=dict)

    def register(self, device: Device) -> Device:
        if not device.device_id.strip():
            raise ValueError("device_id is required")
        if device.device_id in self._devices:
            raise ValueError(f"duplicate device: {device.device_id}")
        self._devices[device.device_id] = device
        return device

    def get(self, device_id: str) -> Device:
        try:
            return self._devices[device_id]
        except KeyError as exc:
            raise KeyError(f"unknown device: {device_id}") from exc

    def has_capability(self, device_id: str, capability: str) -> bool:
        return capability in self.get(device_id).capabilities

    def list(self) -> list[Device]:
        return list(self._devices.values())
