from shadow.core.events import Event

class EventBus:
    def __init__(self):
        self._handlers = {}

    def subscribe(self, event_type: str, handler):
        self._handlers.setdefault(event_type, []).append(handler)

    async def publish(self, event: Event):
        for handler in self._handlers.get(event.type, []):
            await handler(event)
