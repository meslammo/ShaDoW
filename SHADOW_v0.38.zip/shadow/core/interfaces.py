from __future__ import annotations
from typing import Any, Protocol

class ShadowTool(Protocol):
    name: str
    risky: bool
    async def execute(self, arguments: dict[str, Any]) -> Any: ...

class Approval(Protocol):
    async def request(self, tool_name: str, arguments: dict[str, Any], context: dict[str, Any] | None = None) -> bool: ...

class Audit(Protocol):
    async def record(self, tool_name: str, arguments: dict[str, Any], result: Any) -> None: ...
