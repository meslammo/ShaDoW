from __future__ import annotations
from typing import Any, Awaitable, Callable

from shadow.agent.loop import AutonomousAgentLoop

class ShadowRuntime:
    """Understand -> plan -> execute -> critic -> verify -> memory."""
    def __init__(self, planner=None, critic=None, executor=None, policy=None, memory=None, verifier=None, *, brain=None, agent_loop=None, audit=None, learner=None, healer=None, max_step_retries=2, max_replans=1):
        if brain is not None:
            from shadow.reasoning.planner.planner import Planner
            from shadow.reasoning.critic.critic import Critic
            planner = planner or Planner(brain)
            critic = critic or Critic(brain)
        if planner is None or critic is None or executor is None:
            raise ValueError("planner, critic, and executor are required (or provide brain + executor)")
        self.planner, self.critic, self.executor = planner, critic, executor
        self.brain = brain
        self.policy, self.memory, self.verifier = policy, memory, verifier
        self.agent = agent_loop or AutonomousAgentLoop(
            planner, critic, executor, policy=policy, memory=memory, verifier=verifier,
            audit=audit, learner=learner, healer=healer,
            max_step_retries=max_step_retries, max_replans=max_replans,
        )
        self.last_decision = None

    async def run_goal(self, goal: str, tools: dict[str, object] | list[object], *, context=None):
        """Canonical goal-oriented entry point backed by AutonomousAgentLoop."""
        result = await self.agent.run(goal, tools, context=context)
        self.last_decision = result.decision
        return result

    async def run(self, goal: str, tools: dict[str, object] | list[object]):
        manifest = ([{"name": k} for k in tools] if isinstance(tools, dict)
                    else [{"name": getattr(t, "name", str(i))} for i, t in enumerate(tools)])

        if self.policy is not None:
            decision = self.policy.decide(goal) if hasattr(self.policy, "decide") else self.policy(goal)
            self.last_decision = await decision if isinstance(decision, Awaitable) else decision

        plan = await self.planner.plan(goal, manifest)
        results = []
        for step in plan.steps:
            last = None
            for call in step.tool_calls:
                if isinstance(tools, dict):
                    if call.tool not in tools:
                        raise KeyError(f"unknown tool: {call.tool}")
                    tool = tools[call.tool]
                else:
                    tool = next((t for t in tools if getattr(t, "name", None) == call.tool), None)
                    if tool is None:
                        raise KeyError(f"unknown tool: {call.tool}")

                last = await self.executor.execute(
                    tool, call.arguments, risky=bool(getattr(tool, "risky", False)),
                    context={"goal": goal, "step": step.intent},
                )
                results.append(last)

            verdict = await self.critic.evaluate(step, last)
            if verdict.accept and self.verifier is not None:
                checked = self.verifier(step, last)
                verdict.accept = await checked if isinstance(checked, Awaitable) else bool(checked)
                if not verdict.accept and not verdict.reason:
                    verdict.reason = "verification failed"

            if self.memory is not None:
                await self.memory.add_result(goal=goal, step=step.intent, result=last, verdict=verdict)
            if not verdict.accept:
                break
        return results
