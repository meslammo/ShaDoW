"""Runtime registries adapted from OpenJarvis RegistryBase."""
from __future__ import annotations
from typing import Any, Generic, TypeVar
T = TypeVar("T")
class Registry(Generic[T]):
    _items: dict[str, T] = {}
    @classmethod
    def register(cls, key: str, value: T) -> T:
        if key in cls._items: raise ValueError(f"{key} already registered")
        cls._items[key] = value
        return value
    @classmethod
    def get(cls, key: str) -> T: return cls._items[key]
    @classmethod
    def contains(cls, key: str) -> bool: return key in cls._items
    @classmethod
    def items(cls): return tuple(cls._items.items())
    @classmethod
    def clear(cls): cls._items.clear()
class ModelRegistry(Registry[Any]): pass
class EngineRegistry(Registry[Any]): pass
class MemoryRegistry(Registry[Any]): pass
class AgentRegistry(Registry[Any]): pass
class ToolRegistry(Registry[Any]): pass
class RouterPolicyRegistry(Registry[Any]): pass
class SpeechRegistry(Registry[Any]): pass
class TTSRegistry(Registry[Any]): pass
class ConnectorRegistry(Registry[Any]): pass
