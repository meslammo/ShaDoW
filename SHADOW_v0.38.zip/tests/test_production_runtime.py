import asyncio
import json
from shadow.production import ShadowConfig, ProductionRuntime

class Core:
    async def run_goal(self, goal, tools, context=None):
        return {"goal": goal, "context": context}

class Component:
    def __init__(self): self.started = self.stopped = 0
    def start(self): self.started += 1
    def stop(self): self.stopped += 1

def test_config_from_env_and_validation():
    c = ShadowConfig.from_env({"SHADOW_PORT":"9000", "SHADOW_LOG_LEVEL":"debug", "SHADOW_GATEWAY_TOKEN":"secret"})
    assert c.port == 9000 and c.log_level == "DEBUG" and c.gateway_token == "secret"

def test_production_lifecycle_and_health():
    comp = Component(); p = ProductionRuntime(Core(), {}, config=ShadowConfig(request_timeout=1), components={"core": comp})
    p.start(serve=False)
    assert p.health_snapshot()["status"] == "ready" and comp.started == 1
    result = asyncio.run(p.run_goal("hello", context={"x": 1}))
    assert result["context"] == {"x": 1} and p.health_snapshot()["requests"] == 1
    p.stop()
    assert p.health_snapshot()["status"] == "stopped" and comp.stopped == 1

def test_request_timeout_is_counted():
    class Slow:
        async def run_goal(self, *args, **kwargs): await asyncio.sleep(.05)
    p = ProductionRuntime(Slow(), {}, config=ShadowConfig(request_timeout=.01))
    p.start(serve=False)
    try: asyncio.run(p.run_goal("slow"))
    except asyncio.TimeoutError: pass
    else: assert False
    assert p.health_snapshot()["failures"] == 1
    p.stop()
