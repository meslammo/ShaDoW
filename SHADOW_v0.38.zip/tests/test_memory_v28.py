import pytest
from shadow.memory import Memory, MemoryStore

@pytest.mark.anyio
async def test_typed_memory_and_ranked_recall():
    store = MemoryStore()
    await store.add(Memory("semantic", "Browser tasks should use the browser tool."))
    await store.add(Memory("procedural", "Use filesystem for local file tasks."))
    await store.add(Memory("episodic", "Browser task succeeded yesterday."))
    hits = await store.recall("browser task")
    assert hits[0].kind in {"semantic", "episodic"}
    assert len(hits) == 2

@pytest.mark.anyio
async def test_run_memory_is_stored():
    store = MemoryStore()
    m = await store.add_run(goal="test goal", success=True, steps=2)
    assert m.kind == "episodic"
    assert m.metadata["success"] is True
