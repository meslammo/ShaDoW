from pathlib import Path
from shadow.integration.checkpoint import CheckpointManager
from shadow.integration.regression import RegressionEngine
from shadow.integration.rollback import RollbackEngine


def test_regression_pass(tmp_path):
    (tmp_path / 'tests').mkdir()
    (tmp_path / 'tests' / 'test_ok.py').write_text('def test_ok():\n    assert 1 == 1\n')
    result = RegressionEngine().run(tmp_path)
    assert result.passed


def test_regression_failure(tmp_path):
    (tmp_path / 'tests').mkdir()
    (tmp_path / 'tests' / 'test_bad.py').write_text('def test_bad():\n    assert False\n')
    result = RegressionEngine().run(tmp_path)
    assert not result.passed


def test_rollback_removes_new_files(tmp_path):
    (tmp_path / 'old.txt').write_text('old')
    cp = CheckpointManager().create(tmp_path)
    (tmp_path / 'old.txt').write_text('changed')
    (tmp_path / 'new.txt').write_text('new')
    RollbackEngine().rollback(cp, tmp_path)
    assert (tmp_path / 'old.txt').read_text() == 'old'
    assert not (tmp_path / 'new.txt').exists()
