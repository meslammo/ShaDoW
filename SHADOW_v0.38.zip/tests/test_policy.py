from shadow.reasoning.policy.reuse_policy import Decision, decide

def test_reuse_priority():
    assert decide(existing_good=True, existing_incomplete=False,
                  open_source_available=True) == Decision.REUSE

def test_build_when_nothing_exists():
    assert decide(existing_good=False, existing_incomplete=False,
                  open_source_available=False) == Decision.BUILD
