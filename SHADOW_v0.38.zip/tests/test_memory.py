import pytest
from shadow.memory.store import Memory, MemoryStore

@pytest.mark.anyio
async def test_memory_recall():
    store = MemoryStore()
    await store.add(Memory("procedural", "use browser for web tasks"))
    hits = await store.recall("browser")
    assert len(hits) == 1
