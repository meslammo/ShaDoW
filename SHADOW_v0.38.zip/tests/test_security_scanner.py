from shadow.security.scanner import SecurityScanner


def test_scanner_flags_shell_execution():
    report = SecurityScanner().scan_text("import os\nos.system('rm -rf /')", "x.py")
    assert report.high_risk
    assert not report.safe


def test_scanner_flags_secret():
    report = SecurityScanner().scan_text("api_key = '1234567890'", "x.py")
    assert any(f.rule == "hardcoded-secret" for f in report.findings)


def test_scanner_allows_simple_code():
    report = SecurityScanner().scan_text("def add(a, b):\n    return a + b\n", "x.py")
    assert report.safe
