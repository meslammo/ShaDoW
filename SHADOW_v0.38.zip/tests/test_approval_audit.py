import pytest
from shadow.security.approval import ApprovalGateway
from shadow.security.executor.tool_executor import ActionDenied, SecureToolExecutor
from shadow.audit.trail import AuditTrail

class Tool:
    name = "danger"
    risky = True
    async def execute(self, arguments):
        return {"ok": arguments["x"]}

@pytest.mark.asyncio
async def test_risky_action_denied_without_approval():
    audit = AuditTrail()
    with pytest.raises(ActionDenied):
        await SecureToolExecutor(audit=audit).execute(Tool(), {"x": 1}, risky=True)
    assert [e.event for e in audit.events()] == ["action_requested", "action_denied"]

@pytest.mark.asyncio
async def test_approval_and_execution_are_audited():
    audit = AuditTrail()
    approval = ApprovalGateway(lambda req: req.tool_name == "danger")
    result = await SecureToolExecutor(approval=approval, audit=audit).execute(Tool(), {"x": 2}, risky=True)
    assert result == {"ok": 2}
    assert [e.event for e in audit.events()] == ["action_requested", "action_approved", "action_executed"]
