import os
import pytest
from shadow.security.policy import PermissionRule, PolicyDenied, SecurityPolicy
from shadow.security.redaction import SecretRedactor
from shadow.security.secrets import SecretStore
from shadow.security.executor.tool_executor import ActionDenied, SecureToolExecutor
from shadow.audit.trail import AuditTrail
from shadow.security.sandbox import SandboxRunner

class Tool:
    name = "lights.on"
    async def execute(self, arguments):
        return {"token": "should-not-leak", "ok": True}

@pytest.mark.asyncio
async def test_policy_is_fail_closed_and_executor_enforces_it():
    with pytest.raises(PolicyDenied):
        SecurityPolicy().check("x", {}, {})
    policy = SecurityPolicy(); policy.add(PermissionRule("lights.on", allow=True, required_context=("user",)))
    audit = AuditTrail()
    result = await SecureToolExecutor(audit=audit, policy=policy).execute(Tool(), {"password":"abc"}, context={"user":"m"})
    assert result["ok"]
    assert audit.events()[0].data["arguments"]["password"] == "[REDACTED]"
    assert audit.events()[-1].data["result"]["token"] == "[REDACTED]"

@pytest.mark.asyncio
async def test_policy_denial_is_audit_safe():
    audit=AuditTrail()
    with pytest.raises(ActionDenied):
        await SecureToolExecutor(audit=audit, policy=SecurityPolicy()).execute(Tool(), {"token":"secret-value"})
    assert audit.events()[-1].event == "action_denied"


def test_secret_store_reads_only_prefixed_environment(monkeypatch):
    monkeypatch.setenv("SHADOW_TEST_TOKEN", "value")
    assert SecretStore().get("TEST_TOKEN") == "value"
    assert not SecretStore().has("OTHER")


def test_redactor_handles_nested_values():
    out=SecretRedactor().redact({"headers":{"Authorization":"Bearer abc"}, "items":[{"api_key":"x"}]})
    assert out["headers"]["Authorization"] == "[REDACTED]"
    assert out["items"][0]["api_key"] == "[REDACTED]"


def test_sandbox_executable_allowlist(tmp_path):
    runner=SandboxRunner(allowed_executables={"python"})
    with pytest.raises(PermissionError):
        runner.run(["sh", "-c", "echo nope"])
