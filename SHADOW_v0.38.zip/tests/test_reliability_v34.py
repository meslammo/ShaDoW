import pytest

from shadow.agent.loop import AutonomousAgentLoop
from shadow.evaluation.reliability import ReliabilityEvaluator, ReliabilityScenario
from shadow.reasoning.planner.planner import Plan, Step, ToolCall
from shadow.reasoning.critic.critic import Verdict


class Tool:
    def __init__(self, name="echo"):
        self.name = name
        self.risky = False

    async def execute(self, arguments):
        return arguments["value"]


class Planner:
    def __init__(self, values):
        self.values = list(values)
        self.calls = 0

    async def plan(self, goal, tools):
        value = self.values[min(self.calls, len(self.values) - 1)]
        self.calls += 1
        return Plan(goal=goal, steps=[Step(intent=f"step-{self.calls}", tool_calls=[ToolCall(tool="echo", arguments={"value": value})])])


class Critic:
    async def evaluate(self, step, observation):
        return Verdict(accept=observation == "ok", reason="ok" if observation == "ok" else "failure")


class Executor:
    async def execute(self, tool, arguments, **kwargs):
        return await tool.execute(arguments)


@pytest.mark.asyncio
async def test_reliability_evaluator_success_invariants():
    agent = AutonomousAgentLoop(Planner(["ok"]), Critic(), Executor(), max_step_retries=1)
    evaluator = ReliabilityEvaluator(agent.run)
    report = await evaluator.run([ReliabilityScenario("happy", "hello", {"echo": Tool()})])
    assert report.total == report.passed == 1
    assert report.success_rate == 1.0


@pytest.mark.asyncio
async def test_reliability_evaluator_expected_failure_is_valid():
    agent = AutonomousAgentLoop(Planner(["bad"]), Critic(), Executor(), max_step_retries=1, max_replans=0)
    evaluator = ReliabilityEvaluator(agent.run)
    report = await evaluator.run([ReliabilityScenario("failure", "hello", {"echo": Tool()}, expected_success=False)])
    assert report.passed == 1
    assert report.results[0].actual_success is False


@pytest.mark.asyncio
async def test_recovery_scenario_replans_and_completes():
    planner = Planner(["bad", "ok"])
    agent = AutonomousAgentLoop(planner, Critic(), Executor(), max_step_retries=1, max_replans=1)
    result = await agent.run("recover", {"echo": Tool()})
    assert result.success is True
    assert "replanned" in result.events


@pytest.mark.asyncio
async def test_reliability_timeout_is_reported():
    async def slow_runner(*args, **kwargs):
        import asyncio
        await asyncio.sleep(0.05)

    evaluator = ReliabilityEvaluator(slow_runner, timeout_s=0.001)
    report = await evaluator.run([ReliabilityScenario("timeout", "x", {}, expected_success=True)])
    assert report.passed == 0
    assert "runner exception" in report.results[0].invariant_errors[0]


@pytest.mark.asyncio
async def test_unknown_tool_failure_is_fail_closed():
    agent = AutonomousAgentLoop(Planner(["ok"]), Critic(), Executor(), max_step_retries=1)
    evaluator = ReliabilityEvaluator(agent.run)
    report = await evaluator.run([ReliabilityScenario("unknown", "x", {}, expected_success=False)])
    item = report.results[0]
    assert item.passed is True
    assert item.actual_success is False
    assert "step-failed" in item.events
