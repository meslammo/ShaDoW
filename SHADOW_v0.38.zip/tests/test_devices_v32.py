import pytest
from shadow.devices import Device, DeviceCatalog, HomeAssistantControlTool, HomeAssistantStateTool, HomeAssistantTool
from shadow.security.approval import ApprovalGateway
from shadow.security.executor.tool_executor import ActionDenied, SecureToolExecutor

class FakeTransport:
    def __init__(self): self.calls = []
    async def request(self, method, path, payload=None):
        self.calls.append((method, path, payload))
        return {"ok": True}

@pytest.mark.anyio
async def test_catalog_and_home_assistant_read():
    catalog = DeviceCatalog()
    catalog.register(Device("lamp-1", "Lamp", "home_assistant", ("power",)))
    assert catalog.has_capability("lamp-1", "power")
    transport = FakeTransport()
    tool = HomeAssistantStateTool(transport)
    result = await tool.execute({"action": "get_state", "entity_id": "light.lamp"})
    assert result == {"ok": True}
    assert transport.calls == [("GET", "/api/states/light.lamp", None)]

@pytest.mark.anyio
async def test_home_assistant_service_allowlist():
    transport = FakeTransport()
    tool = HomeAssistantControlTool(transport, allowed_services={("light", "turn_on")})
    with pytest.raises(PermissionError):
        await tool.execute({"action": "call_service", "domain": "light", "service": "turn_off"})
    await tool.execute({"action": "call_service", "domain": "light", "service": "turn_on", "service_data": {"entity_id": "light.lamp"}})
    assert transport.calls[-1][0] == "POST"
    assert transport.calls[-1][1] == "/api/services/light/turn_on"

@pytest.mark.anyio
async def test_device_write_requires_secure_approval():
    transport = FakeTransport()
    tool = HomeAssistantControlTool(transport, allowed_services={("light", "turn_on")})
    executor = SecureToolExecutor()
    with pytest.raises(ActionDenied):
        await executor.execute(tool, {"action": "call_service", "domain": "light", "service": "turn_on"}, risky=True)

@pytest.mark.anyio
async def test_device_write_approved():
    transport = FakeTransport()
    tool = HomeAssistantControlTool(transport, allowed_services={("light", "turn_on")})
    executor = SecureToolExecutor(approval=ApprovalGateway(lambda *_: True))
    await executor.execute(tool, {"action": "call_service", "domain": "light", "service": "turn_on", "service_data": {}}, risky=True)
    assert len(transport.calls) == 1
