import pytest
from shadow.reasoning.planner.planner import Planner, Plan
from shadow.reasoning.critic.critic import Critic
from shadow.core.registry import ToolRegistry

def test_plan_schema():
    p = Plan(goal='x', steps=[{'intent':'do','tool_calls':[{'tool':'a','arguments':{}}]}])
    assert p.steps[0].tool_calls[0].tool == 'a'

def test_registry():
    ToolRegistry.clear(); ToolRegistry.register('x', object())
    assert ToolRegistry.contains('x')

@pytest.mark.asyncio
async def test_planner_adapter_contract():
    class P:
        async def create_plan(self, goal, tools):
            return {'steps':[{'intent':'do','tool_calls':[]}]}
    plan = await Planner(P()).plan('goal', [])
    assert plan.goal == 'goal'
