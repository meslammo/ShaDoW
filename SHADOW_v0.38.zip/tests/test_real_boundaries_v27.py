import asyncio, json, sys
import pytest
from shadow.tools.browser import BrowserAdapter
from shadow.tools.computer import ComputerUseAdapter
from shadow.tools.mcp import MCPClientAdapter

@pytest.mark.asyncio
async def test_browser_real_jsonl_runner(tmp_path):
    p=tmp_path/'runner.py'; p.write_text('import sys,json\nfor l in sys.stdin:\n print(json.dumps({"ok":True,"task":json.loads(l)["task"]}),flush=True)')
    r=BrowserAdapter(command=[sys.executable,str(p)])
    assert await r.run('open example') == {'ok':True,'task':'open example'}

@pytest.mark.asyncio
async def test_computer_real_jsonl_runner(tmp_path):
    p=tmp_path/'runner.py'; p.write_text('import sys,json\nfor l in sys.stdin:\n print(json.dumps({"ok":True,"goal":json.loads(l)["goal"]}),flush=True)')
    r=ComputerUseAdapter(command=[sys.executable,str(p)])
    assert await r.run('click button') == {'ok':True,'goal':'click button'}

@pytest.mark.asyncio
async def test_mcp_stdio_initialize_and_call(tmp_path):
    p=tmp_path/'mcp.py'; p.write_text('''import sys,json\nfor l in sys.stdin:\n m=json.loads(l)\n if "id" in m:\n  if m["method"]=="initialize": r={"protocolVersion":"2025-06-18","capabilities":{},"serverInfo":{"name":"test","version":"1"}}\n  elif m["method"]=="tools/call": r={"content":[{"type":"text","text":"ok"}]}\n  elif m["method"]=="tools/list": r={"tools":[]}\n  else: r={}\n  print(json.dumps({"jsonrpc":"2.0","id":m["id"],"result":r}),flush=True)\n''')
    c=MCPClientAdapter(command=[sys.executable,str(p)])
    assert await c.call('demo',{'x':1}) == {'content':[{'type':'text','text':'ok'}]}
    await c.close()
