import asyncio
import pytest
from shadow.perception.voice import VoicePipeline, CallableSTT, CallableTTS, CallableBrain, PassthroughVAD

@pytest.mark.asyncio
async def test_voice_turn_wake_to_tts():
    spoken=[]
    p=VoicePipeline(vad=PassthroughVAD(), stt=CallableSTT(lambda a: "turn on light"),
                    brain=CallableBrain(lambda text, ctx: "Done"),
                    tts=CallableTTS(spoken.append))
    r=await p.run_turn(b"audio", context={"room":"home"})
    assert r.transcript == "turn on light" and r.response == "Done" and spoken == ["Done"]

@pytest.mark.asyncio
async def test_empty_vad_is_noop_turn():
    class V:
        async def filter(self, audio): return None
    p=VoicePipeline(vad=V(), stt=CallableSTT(lambda a: "never"))
    assert (await p.run_turn(b"x")).transcript == ""

@pytest.mark.asyncio
async def test_barge_in_calls_stop():
    stopped=[]
    started=asyncio.Event()
    async def speak(text):
        started.set(); await asyncio.sleep(10)
    async def stop(): stopped.append(True)
    cancel=asyncio.Event()
    p=VoicePipeline(stt=CallableSTT(lambda a: "hi"), brain=CallableBrain(lambda t,c:"hello"),
                    tts=CallableTTS(speak, stop))
    task=asyncio.create_task(p.run_turn(b"x", cancel_event=cancel))
    await started.wait(); cancel.set(); r=await task
    assert r.interrupted is True and stopped == [True]
