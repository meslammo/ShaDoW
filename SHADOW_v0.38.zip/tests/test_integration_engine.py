from pathlib import Path
import pytest

from shadow.integration.engine import IntegrationConflict, IntegrationEngine


def test_plan_and_apply_copies_selected_files(tmp_path: Path):
    source = tmp_path / "source"
    target = tmp_path / "target"
    source.mkdir()
    (source / "module.py").write_text("VALUE = 42\n")
    (source / "ignore.txt").write_text("nope\n")

    engine = IntegrationEngine()
    plan = engine.plan(source, target, ["module.py"])
    result = engine.apply(plan)

    assert result.copied == ["module.py"]
    assert (target / "module.py").read_text() == "VALUE = 42\n"
    assert result.manifest[0]["path"] == "module.py"
    assert len(result.manifest[0]["sha256"]) == 64


def test_conflict_fails_by_default(tmp_path: Path):
    source, target = tmp_path / "s", tmp_path / "t"
    source.mkdir(); target.mkdir()
    (source / "x.py").write_text("new")
    (target / "x.py").write_text("old")
    plan = IntegrationEngine().plan(source, target, ["x.py"])
    with pytest.raises(IntegrationConflict):
        IntegrationEngine().apply(plan)
    assert (target / "x.py").read_text() == "old"


def test_skip_and_overwrite_modes(tmp_path: Path):
    source, target = tmp_path / "s", tmp_path / "t"
    source.mkdir(); target.mkdir()
    (source / "x.py").write_text("new")
    (target / "x.py").write_text("old")
    engine = IntegrationEngine()

    skipped = engine.apply(engine.plan(source, target, ["x.py"], mode="skip"))
    assert skipped.skipped == ["x.py"]
    assert (target / "x.py").read_text() == "old"

    overwritten = engine.apply(engine.plan(source, target, ["x.py"], mode="overwrite"))
    assert overwritten.overwritten == ["x.py"]
    assert (target / "x.py").read_text() == "new"


def test_unsafe_paths_are_rejected(tmp_path: Path):
    source = tmp_path / "s"; source.mkdir()
    with pytest.raises(ValueError):
        IntegrationEngine().plan(source, tmp_path / "t", ["../escape.py"])
