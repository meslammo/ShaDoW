import pytest
from types import SimpleNamespace
from shadow.models import ModelRouter, ShadowBrain
from shadow.reasoning.planner.planner import Planner
from shadow.reasoning.critic.critic import Critic


class Provider:
    def __init__(self, name, text):
        self.name = name
        self.model = name + '-model'
        self.text = text
        self.calls = []

    async def complete(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(text=self.text, model=self.model, provider=self.name)


@pytest.mark.anyio
async def test_brain_routes_planner_and_critic_by_task():
    planner_provider = Provider('planner-provider', '{"steps":[{"intent":"inspect","tool_calls":[]}]}')
    critic_provider = Provider('critic-provider', '{"accept":true,"reason":"ok"}')
    router = ModelRouter({'planner': planner_provider, 'critic': critic_provider}, default='planner')
    brain = ShadowBrain(router, task_providers={'planning': 'planner', 'critique': 'critic'})

    planner = Planner(brain)
    plan = await planner.plan('inspect project', [])
    critic = Critic(brain)
    verdict = await critic.evaluate(plan.steps[0], 'done')

    assert plan.steps[0].intent == 'inspect'
    assert verdict.accept is True
    assert len(planner_provider.calls) == 1
    assert len(critic_provider.calls) == 1


def test_brain_fails_closed_for_unknown_task_provider():
    provider = Provider('p', '{}')
    brain = ShadowBrain(ModelRouter({'p': provider}, default='p'), task_providers={'vision': 'missing'})
    with pytest.raises(KeyError):
        brain.provider_for('vision')
