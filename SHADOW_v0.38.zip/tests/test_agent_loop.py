import pytest
from shadow.agent.loop import AutonomousAgentLoop
from shadow.reasoning.planner.planner import Plan, Step, ToolCall
from shadow.reasoning.critic.critic import Verdict
from shadow.learning.loop import LearningLoop
from shadow.audit.trail import AuditTrail

class Tool:
    name = "echo"
    risky = False
    async def execute(self, arguments):
        return arguments["value"]

class PlannerStub:
    async def plan(self, goal, tools):
        return Plan(goal=goal, steps=[Step(intent="echo", tool_calls=[ToolCall(tool="echo", arguments={"value": "ok"})])])

class CriticStub:
    def __init__(self): self.calls = 0
    async def evaluate(self, step, observation):
        self.calls += 1
        return Verdict(accept=observation == "ok", reason="good" if observation == "ok" else "bad")

class ExecutorStub:
    async def execute(self, tool, arguments, **kwargs):
        return await tool.execute(arguments)

class PolicyStub:
    async def decide(self, goal, context=None):
        return type("Decision", (), {"candidate": type("C", (), {"source":"stub"})(), "decision":"REUSE", "goal":goal})()

@pytest.mark.asyncio
async def test_agent_loop_completes_and_audits_and_learns():
    audit, learning = AuditTrail(), LearningLoop()
    loop = AutonomousAgentLoop(PlannerStub(), CriticStub(), ExecutorStub(), policy=PolicyStub(), audit=audit, learner=learning)
    result = await loop.run("say ok", {"echo": Tool()})
    assert result.success is True
    assert "completed" in result.events
    assert learning.success_rate("stub") == 1.0
    assert any(e.event == "agent.completed" for e in audit.events())

@pytest.mark.asyncio
async def test_agent_loop_unknown_tool_fails_closed():
    loop = AutonomousAgentLoop(PlannerStub(), CriticStub(), ExecutorStub(), max_step_retries=1)
    result = await loop.run("bad", {})
    assert result.success is False
    assert "unknown tool" in result.error

@pytest.mark.asyncio
async def test_agent_loop_replans_after_failed_step():
    class ReplanPlanner:
        def __init__(self): self.calls = 0
        async def plan(self, goal, tools):
            self.calls += 1
            value = "ok" if self.calls == 2 else "bad"
            return Plan(goal=goal, steps=[Step(intent=f"attempt-{self.calls}", tool_calls=[ToolCall(tool="echo", arguments={"value": value})])])

    planner = ReplanPlanner()
    loop = AutonomousAgentLoop(planner, CriticStub(), ExecutorStub(), max_step_retries=1, max_replans=1)
    result = await loop.run("recover", {"echo": Tool()})
    assert result.success is True
    assert planner.calls == 2
    assert "replanned" in result.events

@pytest.mark.asyncio
async def test_agent_loop_uses_async_healer():
    class Healer:
        def __init__(self): self.calls = 0
        async def async_run(self, operation, *, repair=None, success=None):
            self.calls += 1
            value = await operation()
            return type("Healing", (), {"success": bool(success(value)), "attempts": ((1, True),), "final_error": None})()

    healer = Healer()
    loop = AutonomousAgentLoop(PlannerStub(), CriticStub(), ExecutorStub(), healer=healer, max_step_retries=1)
    result = await loop.run("say ok", {"echo": Tool()})
    assert result.success is True
    assert healer.calls == 1
