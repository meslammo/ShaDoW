from pathlib import Path

from shadow.integration.transaction import IntegrationTransaction


def _tests(root: Path, body: str):
    (root / "tests").mkdir()
    (root / "tests" / "test_regression.py").write_text(body)


def test_transaction_commits_on_regression_pass(tmp_path):
    source = tmp_path / "source"; target = tmp_path / "target"
    source.mkdir(); target.mkdir()
    (source / "module.py").write_text("VALUE = 42\n")
    _tests(target, "def test_ok():\n    assert True\n")
    result = IntegrationTransaction().run(source, target, ["module.py"])
    assert result.committed and not result.rolled_back
    assert (target / "module.py").exists()


def test_transaction_rolls_back_on_regression_failure(tmp_path):
    source = tmp_path / "source"; target = tmp_path / "target"
    source.mkdir(); target.mkdir()
    (target / "existing.txt").write_text("before\n")
    (source / "module.py").write_text("VALUE = 42\n")
    _tests(target, "def test_bad():\n    assert False\n")
    result = IntegrationTransaction().run(source, target, ["module.py"])
    assert not result.committed and result.rolled_back
    assert not (target / "module.py").exists()
    assert (target / "existing.txt").read_text() == "before\n"
    assert result.regression and not result.regression.passed
