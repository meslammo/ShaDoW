import pytest
from shadow.tools.filesystem import FilesystemTool
from shadow.tools.registry import ToolCatalog
from shadow.tools.mcp import MCPClientAdapter, MCPTool

@pytest.mark.asyncio
async def test_filesystem_tool_is_root_constrained(tmp_path):
    tool = FilesystemTool(tmp_path)
    await tool.execute({"operation": "write", "path": "a.txt", "content": "hello"})
    assert await tool.execute({"operation": "read", "path": "a.txt"}) == "hello"
    assert "a.txt" in await tool.execute({"operation": "list", "path": "."})
    with pytest.raises(PermissionError):
        await tool.execute({"operation": "read", "path": "../outside.txt"})

@pytest.mark.asyncio
async def test_mcp_tool_uses_injected_transport():
    calls = []
    async def caller(name, args):
        calls.append((name, args)); return {"ok": True}
    tool = MCPTool(MCPClientAdapter(caller), "search")
    assert await tool.execute({"q": "shadow"}) == {"ok": True}
    assert calls == [("search", {"q": "shadow"})]

def test_tool_catalog_manifest_and_duplicate_guard():
    class T:
        name = "x"; risky = True; description = "demo"
        async def execute(self, arguments): return None
    catalog = ToolCatalog([T()])
    assert catalog.manifest() == [{"name": "x", "risky": True, "description": "demo"}]
    with pytest.raises(ValueError): catalog.register(T())
