import pytest

from shadow.reasoning.policy.web_discovery import WebSolutionDiscovery


@pytest.mark.asyncio
async def test_web_discovery_parses_results(monkeypatch):
    class Response:
        text = '''
        <a class="result__a" href="https://github.com/example/project">Example Project</a>
        <div class="result__snippet">Open source project. MIT License. Repository.</div>
        '''
        def raise_for_status(self): pass

    class Client:
        def __init__(self, *args, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def get(self, *args, **kwargs): return Response()

    monkeypatch.setattr("shadow.reasoning.policy.web_discovery.httpx.AsyncClient", Client)
    results = await WebSolutionDiscovery(max_results=3).search("workflow engine")
    assert len(results) == 1
    assert results[0].license == "MIT"
    assert results[0].location.endswith("/example/project")


@pytest.mark.asyncio
async def test_web_discovery_fails_closed_on_unknown_license(monkeypatch):
    class Response:
        text = '''<a class="result__a" href="https://example.com/project">Project</a>'''
        def raise_for_status(self): pass

    class Client:
        def __init__(self, *args, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def get(self, *args, **kwargs): return Response()

    monkeypatch.setattr("shadow.reasoning.policy.web_discovery.httpx.AsyncClient", Client)
    results = await WebSolutionDiscovery().search("something")
    assert results[0].license is None
