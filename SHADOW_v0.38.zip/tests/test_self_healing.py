from shadow.recovery.healing import SelfHealingEngine


def test_healing_repairs_then_succeeds():
    state = {"ok": False, "repairs": 0}

    def operation():
        return state["ok"]

    def repair(_failure):
        state["repairs"] += 1
        state["ok"] = True

    result = SelfHealingEngine(max_attempts=2).run(operation, repair=repair)
    assert result.success
    assert len(result.attempts) == 2
    assert state["repairs"] == 1


def test_healing_is_bounded():
    calls = []
    result = SelfHealingEngine(max_attempts=3).run(
        lambda: False,
        repair=lambda _: calls.append(1),
    )
    assert not result.success
    assert len(result.attempts) == 3
    assert len(calls) == 2


def test_healing_does_not_retry_without_repair():
    result = SelfHealingEngine(max_attempts=5).run(lambda: False)
    assert not result.success
    assert len(result.attempts) == 1
