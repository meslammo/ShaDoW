from importlib.metadata import PackageNotFoundError

from shadow.reasoning.policy.dependency_verifier import DependencyVerifier


def test_parse_requirements_ignores_options_and_comments():
    reqs = DependencyVerifier.parse_requirements("# hi\npydantic>=2 # core\n-r requirements/base.txt\n")
    assert reqs == ["pydantic>=2"]


def test_dependency_verifier_accepts_installed_requirement():
    result = DependencyVerifier().verify_requirements(["packaging>=20"])
    assert result.verified is True
    assert result.dependencies[0].installed


def test_dependency_verifier_rejects_missing_package():
    result = DependencyVerifier().verify_requirements(["shadow-package-that-does-not-exist-999999"])
    assert result.verified is False
    assert result.dependencies[0].installed is None
