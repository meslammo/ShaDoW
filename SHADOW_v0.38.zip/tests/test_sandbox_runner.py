import sys

from shadow.security.sandbox import SandboxRunner


def test_sandbox_runs_in_disposable_workspace(tmp_path):
    source = tmp_path / "candidate"
    source.mkdir()
    (source / "main.py").write_text("print('ok')", encoding="utf-8")
    runner = SandboxRunner(timeout_seconds=5)
    result = runner.run([sys.executable, "main.py"], source_dir=source)
    assert result.ok
    assert result.stdout.strip() == "ok"
    assert not (source / "created.txt").exists()


def test_sandbox_timeout():
    runner = SandboxRunner(timeout_seconds=0.05)
    result = runner.run([sys.executable, "-c", "import time; time.sleep(1)"])
    assert result.timed_out
    assert not result.ok


def test_sandbox_rejects_shell_strings():
    runner = SandboxRunner()
    try:
        runner.run("python -c print(1)")
    except ValueError:
        pass
    else:
        raise AssertionError("string command should be rejected")
