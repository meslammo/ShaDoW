import sys, types
import pytest
from shadow.production import ShadowConfig, ProductionRuntime, build_runtime, load_factory

class DummyRuntime(ProductionRuntime):
    pass

def test_load_factory_and_build_runtime(monkeypatch):
    module = types.ModuleType("test_shadow_factory")
    module.make = lambda: ProductionRuntime(object(), {})
    monkeypatch.setitem(sys.modules, module.__name__, module)
    assert load_factory("test_shadow_factory:make") is module.make
    runtime = build_runtime("test_shadow_factory:make", config=ShadowConfig())
    assert isinstance(runtime, ProductionRuntime)

def test_bootstrap_requires_factory(monkeypatch):
    monkeypatch.delenv("SHADOW_APP_FACTORY", raising=False)
    with pytest.raises(RuntimeError):
        build_runtime()

def test_bootstrap_rejects_bad_factory(monkeypatch):
    module = types.ModuleType("bad_shadow_factory")
    module.make = lambda: object()
    monkeypatch.setitem(sys.modules, module.__name__, module)
    with pytest.raises(TypeError):
        build_runtime("bad_shadow_factory:make")
