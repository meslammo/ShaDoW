import pytest
from shadow.reasoning.policy.engine import SolutionCandidate
from shadow.reasoning.scoring import DecisionScorer
from shadow.capabilities import Capability, CapabilityRegistry
from shadow.audit import AuditTrail


def test_scoring_prefers_quality_and_completeness():
    scorer = DecisionScorer()
    a = SolutionCandidate("a", "m", "x", "MIT", quality=.9, completeness=.9)
    b = SolutionCandidate("b", "m", "x", "MIT", quality=.5, completeness=.5)
    assert scorer.rank([b, a])[0].candidate is a
    assert scorer.score(a) > scorer.score(b)


def test_capability_registry():
    r = CapabilityRegistry()
    r.register(Capability("voice", "speech", "local"))
    assert r.has("voice")
    assert r.missing(["voice", "vision"]) == ["vision"]


@pytest.mark.asyncio
async def test_audit_trail():
    trail = AuditTrail()
    event = await trail.record("decision", decision="REUSE")
    assert event.event == "decision"
    assert trail.events()[0].data["decision"] == "REUSE"
