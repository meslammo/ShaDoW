from shadow.reasoning.policy.compatibility import CompatibilityEngine


def test_python_compatible():
    engine = CompatibilityEngine(python_version="3.11.8", system="Linux")
    report = engine.verify_project_text('requires-python = ">=3.11"')
    assert report.compatible


def test_python_incompatible_fails_closed():
    engine = CompatibilityEngine(python_version="3.11.8", system="Linux")
    report = engine.verify_project_text('requires-python = ">=3.12"')
    assert not report.compatible


def test_os_restriction():
    engine = CompatibilityEngine(python_version="3.11.8", system="Linux")
    assert engine.verify_project_text("Supported platforms: Windows, Linux").compatible
    assert not CompatibilityEngine(python_version="3.11.8", system="Linux").verify_project_text("Windows only").compatible


def test_invalid_python_requirement_fails_closed():
    engine = CompatibilityEngine(python_version="3.11.8", system="Linux")
    report = engine.verify_project_text('requires-python = "not-a-specifier"')
    assert not report.compatible
