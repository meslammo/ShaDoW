import pytest
from shadow.core.runtime.runtime import ShadowRuntime
from shadow.reasoning.planner.planner import Planner
from shadow.reasoning.critic.critic import Critic
from shadow.security.executor.tool_executor import SecureToolExecutor
from shadow.reasoning.policy.reuse_policy import Decision

class Provider:
    async def create_plan(self, goal, tools):
        return {"steps":[{"intent":"run","tool_calls":[{"tool":"echo","arguments":{"x":1}}]}]}
    async def critique(self, step, observation):
        return {"accept": True, "reason": "ok"}

class Tool:
    name = "echo"
    risky = False
    async def execute(self, arguments):
        return arguments["x"]

@pytest.mark.asyncio
async def test_runtime_records_policy_and_verifies():
    rt = ShadowRuntime(
        Planner(Provider()), Critic(Provider()), SecureToolExecutor(),
        policy=lambda goal: Decision.REUSE,
        verifier=lambda step, result: result == 1,
    )
    assert await rt.run("test", {"echo": Tool()}) == [1]
    assert rt.last_decision == Decision.REUSE

@pytest.mark.asyncio
async def test_runtime_rejects_unknown_tool():
    rt = ShadowRuntime(Planner(Provider()), Critic(Provider()), SecureToolExecutor())
    with pytest.raises(KeyError, match="unknown tool"):
        await rt.run("test", {})

@pytest.mark.asyncio
async def test_runtime_run_goal_uses_autonomous_agent_loop():
    rt = ShadowRuntime(Planner(Provider()), Critic(Provider()), SecureToolExecutor())
    result = await rt.run_goal("test", {"echo": Tool()})
    assert result.success is True
    assert result.steps[0].observation == 1
