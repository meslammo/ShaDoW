import pytest
from types import SimpleNamespace
from shadow.models.openai import OpenAIProvider
from shadow.models.router import ModelRouter

class FakeResponses:
    async def create(self, **kwargs):
        self.kwargs = kwargs
        return SimpleNamespace(output_text='hello', model=kwargs['model'], usage=SimpleNamespace(input_tokens=2, output_tokens=3, total_tokens=5))

class FakeClient:
    def __init__(self): self.responses = FakeResponses()

@pytest.mark.anyio
async def test_openai_provider_uses_responses_api_without_network():
    client = FakeClient()
    p = OpenAIProvider(client=client)
    result = await p.complete(model='test-model', system='sys', messages=[{'role':'user','content':'hi'}])
    assert result.text == 'hello'
    assert result.provider == 'openai'
    assert result.usage['total_tokens'] == 5
    assert client.responses.kwargs['input'][0]['role'] == 'system'
    assert client.responses.kwargs['max_output_tokens'] == 4096

@pytest.mark.anyio
async def test_router_selects_explicit_provider():
    a = OpenAIProvider(client=FakeClient())
    b = OpenAIProvider(model='other', client=FakeClient())
    router = ModelRouter({'primary': a, 'secondary': b}, default='primary')
    assert router.select(preferred='secondary') is b
    result = await router.complete(preferred='secondary', model='other', system=None, messages=[])
    assert result.model == 'other'

def test_router_fails_closed_for_unknown_provider():
    router = ModelRouter({'primary': OpenAIProvider(client=FakeClient())}, default='primary')
    with pytest.raises(KeyError):
        router.select(preferred='missing')
