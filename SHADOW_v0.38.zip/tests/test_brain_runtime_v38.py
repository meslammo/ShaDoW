import pytest
from types import SimpleNamespace
from shadow.core.runtime.runtime import ShadowRuntime
from shadow.models import ModelRouter, ShadowBrain
from shadow.security.executor.tool_executor import SecureToolExecutor

class Provider:
    def __init__(self, name, text):
        self.name=name; self.model=name+'-model'; self.text=text; self.calls=[]
    async def complete(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(text=self.text, model=self.model, provider=self.name)

class Tool:
    name='echo'; risky=False
    async def execute(self, arguments): return arguments['x']

@pytest.mark.asyncio
async def test_runtime_can_build_reasoning_stack_from_brain():
    planner=Provider('planner', '{"steps":[{"intent":"echo","tool_calls":[{"tool":"echo","arguments":{"x":7}}]}]}')
    critic=Provider('critic', '{"accept":true,"reason":"ok","suggestions":[]}')
    brain=ShadowBrain(ModelRouter({'planner': planner, 'critic': critic}, default='planner'), task_providers={'planning':'planner','critique':'critic'})
    runtime=ShadowRuntime(executor=SecureToolExecutor(), brain=brain)
    result=await runtime.run_goal('say 7', {'echo': Tool()})
    assert result.success
    assert result.steps[0].observation == 7
    assert len(planner.calls) == 1
    assert len(critic.calls) == 1
