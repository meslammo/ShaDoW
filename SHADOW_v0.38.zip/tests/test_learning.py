import pytest
from shadow.learning.loop import LearningExperience, LearningLoop
from shadow.reasoning.policy.engine import SolutionCandidate
from shadow.reasoning.scoring.scorer import DecisionScorer

@pytest.mark.anyio
async def test_learning_records_and_adjusts_confidence():
    learning = LearningLoop()
    await learning.record(LearningExperience("g", "repo", "reuse", True))
    await learning.record(LearningExperience("g2", "repo", "reuse", True))
    assert learning.success_rate("repo") == 1.0
    assert learning.adjustment("repo") == 0.1

@pytest.mark.anyio
async def test_learning_from_decision_and_scorer():
    learning = LearningLoop()
    class R: pass
    r = R(); r.goal = "voice"; r.decision = "reuse"; r.candidate = SolutionCandidate("repo", "m", "x", "MIT", quality=.8, completeness=.8)
    await learning.learn_from_decision(r, True)
    score = DecisionScorer(learning).score(r.candidate)
    assert score > 0.75
