import pytest
from shadow.reasoning.policy.license_verifier import LicenseVerifier
from shadow.reasoning.policy.verified_discovery import VerifiedSolutionDiscovery
from shadow.reasoning.policy.engine import SolutionCandidate

class FakeVerifier:
    async def verify(self, location, claimed_license=None):
        from shadow.reasoning.policy.license_verifier import LicenseVerification
        return LicenseVerification("MIT", True, location, "test") if location == "ok" else LicenseVerification(None, False, location, "missing")

class Discovery:
    async def search(self, goal, context=None):
        return [SolutionCandidate("good", "x", "ok", "GPL-3.0", quality=.9, completeness=.8), SolutionCandidate("bad", "x", "bad", "MIT", quality=.9, completeness=.9)]

@pytest.mark.asyncio
async def test_verified_discovery_uses_evidence_not_claim():
    result = await VerifiedSolutionDiscovery(Discovery(), FakeVerifier()).search("x")
    assert result[0].license == "MIT"
    assert result[0].compatible is True
    assert result[1].license is None
    assert result[1].compatible is False
