import pytest
from shadow.reasoning.policy.engine import ReasoningPolicyEngine, SolutionCandidate
from shadow.reasoning.policy.reuse_policy import Decision

class Discovery:
    def __init__(self, candidates): self.candidates = candidates
    async def search(self, goal, context=None): return self.candidates

@pytest.mark.asyncio
async def test_engine_reuses_good_solution():
    d = Discovery([SolutionCandidate("OpenJarvis", "registry", "github", "Apache-2.0", quality=.95, completeness=.95)])
    r = await ReasoningPolicyEngine(d).decide("registry")
    assert r.decision == Decision.REUSE

@pytest.mark.asyncio
async def test_engine_modifies_incomplete_solution():
    d = Discovery([SolutionCandidate("X", "tool", "github", "MIT", quality=.9, completeness=.5)])
    r = await ReasoningPolicyEngine(d).decide("tool")
    assert r.decision == Decision.MODIFY

@pytest.mark.asyncio
async def test_engine_builds_when_nothing_usable():
    d = Discovery([SolutionCandidate("X", "tool", "github", None, quality=1, completeness=1)])
    r = await ReasoningPolicyEngine(d).decide("tool")
    assert r.decision == Decision.BUILD

@pytest.mark.asyncio
async def test_composite_discovery_deduplicates():
    from shadow.reasoning.policy.discovery import CompositeSolutionDiscovery
    class D:
        def __init__(self, items): self.items = items
        async def search(self, goal, context=None): return self.items
    a = SolutionCandidate("X", "goal", "one", "MIT", quality=.8, completeness=.7)
    b = SolutionCandidate("X", "goal", "two", "MIT", quality=.9, completeness=.8)
    result = await CompositeSolutionDiscovery([D([a]), D([b])]).search("goal")
    assert len(result) == 1 and result[0].location == "two"

@pytest.mark.asyncio
async def test_runtime_accepts_async_policy():
    from shadow.core.runtime.runtime import ShadowRuntime
    class Policy:
        async def decide(self, goal): return "DECISION"
    class Plan:
        steps = []
    class Planner:
        async def plan(self, goal, manifest): return Plan()
    class Critic: pass
    class Executor: pass
    runtime = ShadowRuntime(Planner(), Critic(), Executor(), policy=Policy())
    await runtime.run("x", {})
    assert runtime.last_decision == "DECISION"
