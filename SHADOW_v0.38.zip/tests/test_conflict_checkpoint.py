from pathlib import Path
from shadow.integration.conflicts import ConflictResolver
from shadow.integration.checkpoint import CheckpointManager

def test_conflict_detect_and_diff(tmp_path):
    src=tmp_path/'src'; dst=tmp_path/'dst'; src.mkdir(); dst.mkdir()
    (src/'a.txt').write_text('new\n'); (dst/'a.txt').write_text('old\n')
    r=ConflictResolver(); c=r.detect(src,dst,['a.txt'])
    assert len(c)==1 and 'old' in r.unified_diff(src,dst,'a.txt')

def test_checkpoint_restore(tmp_path):
    root=tmp_path/'root'; root.mkdir(); p=root/'a.txt'; p.write_text('before')
    cp=CheckpointManager().create(root,['a.txt'])
    p.write_text('after'); CheckpointManager().restore(cp,root)
    assert p.read_text()=='before'
