from pathlib import Path

from shadow.analysis.analyzer import ArchitectureAnalyzer


def test_python_architecture_analysis(tmp_path: Path):
    (tmp_path / "main.py").write_text("import os\nfrom shadow.core import registry\n\nclass App: pass\n")
    (tmp_path / "worker.py").write_text("import requests\n\ndef run():\n    return requests.get('x')\n")
    report = ArchitectureAnalyzer().analyze(tmp_path)
    assert report.entrypoints == ["main.py"]
    assert report.module("main.py").symbols == ("App",)
    assert "worker.py" in report.risky_modules
    assert ("main.py", "os") in report.dependency_edges


def test_invalid_root_fails_closed(tmp_path: Path):
    try:
        ArchitectureAnalyzer().analyze(tmp_path / "missing")
    except NotADirectoryError:
        pass
    else:
        raise AssertionError("expected NotADirectoryError")
