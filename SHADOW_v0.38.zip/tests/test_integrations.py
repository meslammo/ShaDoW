from shadow.integrations.personaljarvis.voice import PersonalJarvisVoiceAdapter

def test_adapter_import_is_lazy():
    assert PersonalJarvisVoiceAdapter.__name__ == "PersonalJarvisVoiceAdapter"
