import asyncio, json, threading
from shadow.clients.gateway import ClientRequest, ShadowGateway
from shadow.clients.desktop import DesktopClient

class Runtime:
    async def run_goal(self, goal, tools, context=None):
        from types import SimpleNamespace
        return SimpleNamespace(goal=goal, success=True, decision=None, steps=[], error=None)

def test_protocol_roundtrip():
    r = ClientRequest("1", "health", {"x": 1}, {"device": "android"})
    assert ClientRequest.from_dict(json.loads(r.to_json())) == r

def test_gateway_health_and_goal():
    g = ShadowGateway(Runtime(), {})
    assert asyncio.run(g.handle(ClientRequest("1", "health"))).ok
    out = asyncio.run(g.handle(ClientRequest("2", "run_goal", {"goal": "hello"})))
    assert out.ok and out.data["goal"] == "hello"

def test_gateway_rejects_unknown_action():
    out = asyncio.run(ShadowGateway(Runtime(), {}).handle(ClientRequest("1", "x")))
    assert not out.ok and "unsupported" in out.error

def test_http_auth_and_desktop_client():
    server = ShadowGateway(Runtime(), {}, token="secret").make_server(port=0)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    try:
        c = DesktopClient(f"http://127.0.0.1:{port}", token="secret")
        assert c.health()["ok"]
        out = c.request(ClientRequest("1", "run_goal", {"goal": "test"}))
        assert out["ok"]
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)
