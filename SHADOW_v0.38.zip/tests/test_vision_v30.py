import asyncio
import json
import sys
from pathlib import Path

from shadow.perception.vision import VisionAdapter, VisionPipeline, VisionObservation
from shadow.perception.screen import ScreenAdapter, ScreenFrame


def test_vision_adapter_and_pipeline_with_action_and_verify():
    async def runner(image):
        return {"summary": "login screen", "elements": [{"text": "Sign in"}], "metadata": {"source": image}}

    class Action:
        async def execute(self, args):
            return {"clicked": args["target"]}

    class Verify:
        async def verify(self, observation, result, context):
            return observation.summary == "login screen" and result["clicked"] == "Sign in"

    async def main():
        vision = VisionAdapter(runner=runner)
        cycle = await VisionPipeline(vision, Action(), Verify()).run(
            "frame", context={"screen": "desktop"}, action_arguments={"target": "Sign in"})
        assert cycle.observation.summary == "login screen"
        assert cycle.verified is True
    asyncio.run(main())


def test_vision_subprocess_runner():
    script = Path(__file__).with_name("vision_runner.py")
    script.write_text("import sys,json; p=json.loads(sys.stdin.readline()); print(json.dumps({'summary':'ok','elements':[]}))")
    try:
        async def main():
            adapter = VisionAdapter(command=[sys.executable, str(script)])
            obs = await adapter.analyze("image")
            assert obs.summary == "ok"
        asyncio.run(main())
    finally:
        script.unlink(missing_ok=True)


def test_screen_adapter_injected_runner():
    async def runner():
        return {"image_b64": "aGVsbG8=", "width": 100, "height": 50, "metadata": {"display": 1}}
    async def main():
        frame = await ScreenAdapter(runner=runner).capture()
        assert frame == ScreenFrame(b"hello", 100, 50, {"display": 1})
    asyncio.run(main())
