# SHADOW integration audit — v0.5

## What is now real
- OpenJarvis registry contract adapted into `shadow/core/registry.py`.
- PersonalJarvis single execution-gateway pattern adapted into `shadow/security/executor/tool_executor.py`.
- agent-workflow-mcp typed Planner/Critic contracts adapted into `shadow/reasoning/`.
- Runtime now wires Planner -> SecureToolExecutor -> Critic -> Memory.
- Browser, Computer Use and MCP are executable Shadow tool boundaries with injected runners/transports.
- Voice is a provider-neutral Wake/VAD/STT/TTS boundary.
- Memory now records successful procedural patterns and failed attempts from runtime results.
- Package discovery and pytest configuration are fixed.

## Upstream policy
Shadow does not vendor the large upstream projects. PersonalJarvis and OpenJarvis are Apache-2.0; agent-workflow-mcp is MIT. `brunogcar/agent` is architecture reference only because no LICENSE file was found on its default branch.

## Current status
- 7 tests pass.
- Real upstream runtime dependencies are still optional: the adapters accept the upstream runner/provider objects when installed or supplied.
- No fake claim of a working desktop/browser runtime is made until the corresponding host capability and upstream dependency are actually installed.
