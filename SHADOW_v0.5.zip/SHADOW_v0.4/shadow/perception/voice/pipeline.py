from __future__ import annotations
from typing import Any

class VoicePipeline:
    """Provider-neutral Wake -> VAD -> STT -> brain -> TTS boundary."""
    def __init__(self, wake=None, vad=None, stt=None, tts=None):
        self.wake, self.vad, self.stt, self.tts = wake, vad, stt, tts

    async def transcribe(self, audio: Any):
        if self.vad is not None:
            audio = await self.vad.filter(audio)
        if self.stt is None:
            raise RuntimeError("STT adapter is not configured")
        return await self.stt.transcribe(audio)

    async def speak(self, text: str):
        if self.tts is None:
            raise RuntimeError("TTS adapter is not configured")
        return await self.tts.speak(text)
