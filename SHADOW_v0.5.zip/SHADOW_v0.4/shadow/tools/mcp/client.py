from __future__ import annotations
from typing import Any, Awaitable, Callable

class MCPClientAdapter:
    """MCP boundary. Transport is injected so Shadow core stays provider-neutral."""
    def __init__(self, caller: Callable[[str, dict[str, Any]], Awaitable[Any]] | None = None):
        self._caller = caller

    def bind(self, caller):
        self._caller = caller
        return self

    async def call(self, tool_name: str, arguments: dict[str, Any]):
        if self._caller is None:
            raise RuntimeError("MCP transport is not configured")
        return await self._caller(tool_name, arguments)

    async def execute(self, arguments: dict[str, Any]):
        name = str(arguments.get("tool_name", "")).strip()
        if not name:
            raise ValueError("MCP tool_name is required")
        return await self.call(name, dict(arguments.get("arguments", {})))
