from __future__ import annotations
from typing import Any, Awaitable, Callable

class BrowserAdapter:
    """Shadow tool boundary for an isolated browser-use runner."""
    name = "browser"
    risky = True

    def __init__(self, runner: Callable[[str], Awaitable[Any]] | None = None):
        self._runner = runner

    def bind(self, runner):
        self._runner = runner
        return self

    async def execute(self, arguments: dict[str, Any]):
        task = str(arguments.get("task", "")).strip()
        if not task:
            raise ValueError("browser task is required")
        if self._runner is None:
            raise RuntimeError("isolated browser runner is not configured")
        return await self._runner(task)

    async def run(self, task: str):
        return await self.execute({"task": task})
