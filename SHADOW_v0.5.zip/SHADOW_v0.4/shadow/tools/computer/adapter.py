from __future__ import annotations
from typing import Any, Awaitable, Callable

class ComputerUseAdapter:
    """Shadow tool boundary for PersonalJarvis CU v2 perceive-act-verify."""
    name = "computer"
    risky = True

    def __init__(self, runner: Callable[[str], Awaitable[Any]] | None = None):
        self._runner = runner

    def bind(self, runner):
        self._runner = runner
        return self

    async def execute(self, arguments: dict[str, Any]):
        goal = str(arguments.get("goal", "")).strip()
        if not goal:
            raise ValueError("computer goal is required")
        if self._runner is None:
            raise RuntimeError("PersonalJarvis CU v2 runner is not configured")
        return await self._runner(goal)

    async def run(self, goal: str):
        return await self.execute({"goal": goal})
