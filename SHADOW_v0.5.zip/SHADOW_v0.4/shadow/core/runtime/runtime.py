from __future__ import annotations
from typing import Any

class ShadowRuntime:
    """Understand -> plan -> execute -> critic -> verify -> memory."""
    def __init__(self, planner, critic, executor, policy=None, memory=None):
        self.planner, self.critic, self.executor = planner, critic, executor
        self.policy, self.memory = policy, memory

    async def run(self, goal: str, tools: dict[str, object] | list[object]):
        manifest = ([{"name": k} for k in tools] if isinstance(tools, dict)
                    else [{"name": getattr(t, "name", str(i))} for i, t in enumerate(tools)])
        if self.policy is not None:
            decision = self.policy(goal)
            if getattr(decision, "value", decision) == "build":
                pass
        plan = await self.planner.plan(goal, manifest)
        results = []
        for step in plan.steps:
            last = None
            for call in step.tool_calls:
                tool = tools[call.tool] if isinstance(tools, dict) else next(t for t in tools if getattr(t, "name", None) == call.tool)
                last = await self.executor.execute(
                    tool, call.arguments, risky=bool(getattr(tool, "risky", False)),
                    context={"goal": goal, "step": step.intent},
                )
                results.append(last)
            verdict = await self.critic.evaluate(step, last)
            if self.memory is not None:
                await self.memory.add_result(goal=goal, step=step.intent, result=last, verdict=verdict)
            if not verdict.accept:
                break
        return results
