from __future__ import annotations
from typing import Any

class ActionDenied(PermissionError):
    pass

class SecureToolExecutor:
    """Single execution gateway: approval -> execute -> audit."""
    def __init__(self, approval=None, audit=None):
        self.approval, self.audit = approval, audit

    async def execute(self, tool, arguments: dict[str, Any], *, risky: bool = False, context=None):
        if risky:
            if self.approval is None:
                raise ActionDenied(f"approval required: {getattr(tool, 'name', tool)}")
            allowed = await self.approval.request(getattr(tool, "name", str(tool)), arguments, context=context)
            if not allowed:
                raise ActionDenied(getattr(tool, "name", str(tool)))
        if not hasattr(tool, "execute"):
            raise TypeError(f"tool {tool!r} does not implement execute(arguments)")
        result = await tool.execute(arguments)
        if self.audit is not None:
            await self.audit.record(getattr(tool, "name", str(tool)), arguments, result)
        return result
