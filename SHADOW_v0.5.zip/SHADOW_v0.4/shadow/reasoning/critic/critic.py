"""Shadow critic adapted from agent-workflow-mcp's typed Critic contract."""
from __future__ import annotations
import json
from typing import Any
from pydantic import BaseModel, Field
from shadow.reasoning.planner.planner import Step

class Verdict(BaseModel):
    accept: bool
    reason: str = ""
    suggestions: list[str] = Field(default_factory=list)

class Critic:
    def __init__(self, provider: Any):
        self.provider = provider

    async def evaluate(self, step: Step, observation: Any) -> Verdict:
        if hasattr(self.provider, "complete"):
            response = await self.provider.complete(
                model=getattr(self.provider, "model", "default"),
                system="Evaluate whether the step succeeded. Return JSON only: accept, reason, suggestions.",
                messages=[{"role":"user","content":json.dumps({"intent":step.intent,"observation":observation}, default=str)}],
                max_tokens=512, temperature=0.0)
            text = response.text
        else:
            text = await self.provider.critique(step=step, observation=observation)
            if isinstance(text, dict):
                return Verdict(**text)
        try:
            return Verdict(**json.loads(text))
        except Exception as exc:
            return Verdict(accept=False, reason=f"critic parse error: {exc}", suggestions=["retry step"])
