"""Shadow planner adapted from agent-workflow-mcp's typed Planner contract."""
from __future__ import annotations
import json
from typing import Any
from pydantic import BaseModel, Field

class ToolCall(BaseModel):
    tool: str
    arguments: dict[str, Any] = Field(default_factory=dict)

class Step(BaseModel):
    index: int = 0
    intent: str
    tool_calls: list[ToolCall] = Field(default_factory=list)
    stop_when: str | None = None

class Plan(BaseModel):
    goal: str
    steps: list[Step] = Field(default_factory=list)
    rationale: str | None = None

class Planner:
    """Provider-neutral planner using the upstream JSON plan contract."""
    def __init__(self, provider: Any, *, max_steps: int = 12):
        self.provider = provider
        self.max_steps = max_steps

    async def plan(self, goal: str, tools: list[dict[str, Any]]) -> Plan:
        if hasattr(self.provider, "complete"):
            response = await self.provider.complete(
                model=getattr(self.provider, "model", "default"),
                system=("Turn the goal into a JSON plan. Return JSON only with "
                        "steps:[{intent,tool_calls:[{tool,arguments}],stop_when}], rationale."),
                messages=[{"role": "user", "content": f"Goal: {goal}\nTools: {json.dumps(tools, default=str)}"}],
                max_tokens=4096,
                temperature=0.0,
            )
            raw = json.loads(response.text)
        else:
            raw = await self.provider.create_plan(goal=goal, tools=tools)
        return self._parse(raw, goal)

    def _parse(self, raw: dict[str, Any], goal: str) -> Plan:
        steps = []
        for i, item in enumerate(raw.get("steps", [])):
            steps.append(Step(index=i, intent=item["intent"],
                              tool_calls=[ToolCall(**c) for c in item.get("tool_calls", [])],
                              stop_when=item.get("stop_when")))
        if not steps:
            raise ValueError("planner produced an empty plan")
        if len(steps) > self.max_steps:
            raise ValueError(f"planner exceeded max_steps={self.max_steps}")
        return Plan(goal=goal, steps=steps, rationale=raw.get("rationale"))
