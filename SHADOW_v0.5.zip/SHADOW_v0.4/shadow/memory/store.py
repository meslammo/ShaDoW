from dataclasses import dataclass, field
from typing import Any

@dataclass
class Memory:
    kind: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)

class MemoryStore:
    def __init__(self):
        self._items: list[Memory] = []

    async def add(self, memory: Memory):
        self._items.append(memory)

    async def recall(self, query: str, limit: int = 5):
        q = query.lower().strip()
        if not q:
            return []
        hits = [m for m in self._items if q in m.content.lower()]
        return hits[:limit]

    async def add_result(self, *, goal: str, step: str, result: Any, verdict: Any):
        ok = bool(getattr(verdict, "accept", False))
        kind = "procedural" if ok else "failure"
        await self.add(Memory(kind, f"Goal: {goal}\nStep: {step}\nResult: {result}\nAccepted: {ok}",
                               {"goal": goal, "step": step, "accepted": ok}))
