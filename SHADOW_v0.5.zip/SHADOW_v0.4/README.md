# SHADOW v0.2

Core + adapter boundaries for:
- Voice pipeline
- Computer Use
- Browser
- MCP
- Memory
- EventBus

Heavy external implementations remain isolated behind adapters.
